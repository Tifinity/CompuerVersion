#include "Cut.h"

using namespace std;

Cut::Cut(string filename) {
	origin_img_cv = imread(filename);
	CImg<unsigned char> tmp(filename.c_str());
	origin_img = tmp;
	if (!origin_img.data()) {
		cout << "Could not open or find the image" << std::endl;
		exit(-1);
	}

	visit = new bool[origin_img._width * origin_img._height];
	for (int i = 0; i < origin_img._width * origin_img._height; i++)
		visit[i] = false;

	origin_img.display("origin image");
	gray_img = toGrayScale(origin_img);
	delate_img = delate(gray_img);
	delate_img.display("delate image");
	find_connection();
	result_img = draw(origin_img);
	result_img.display("result image");
	result2_img = find_ruler(result_img);
	result2_img.display("result2 image");
	
	result_img.save("number.bmp");
	result2_img.save("ruler.bmp");

	CImg<unsigned char> tmp2("lena.bmp");
	back_img = background(tmp2);
	back_img.display("back image");
	back_img.save("front_back.bmp");
	knn();
}

Cut::~Cut() {
	delete[]visit;
}

int Cut::getThreshold(CImg<unsigned char> src) {
	int th;
	const int GrayScale = 256;	//��ͨ��ͼ���ܻҶ�256��
	int pixCount[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ���ظ���
	int pixSum = src._width * src._height;//ͼ�������ص�
	float pixPro[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ�����ر���
	float w0, w1, u0tmp, u1tmp, u0, u1, deltaTmp, deltaMax = 0;

	cimg_forXY(src, x, y) {
		pixCount[src(x, y)]++;//ͳ��ÿ���Ҷȼ������صĸ���
	}

	for (int i = 0; i < GrayScale; i++) {
		pixPro[i] = pixCount[i] * 1.0 / pixSum;//����ÿ���Ҷȼ���������Ŀռ����ͼ��ı���  
	}
	//�������д�0��255�Ҷȼ�����ֵ�ָ�������������һ������䷽�����
	for (int i = 0; i < GrayScale; i++) {
		w0 = w1 = u0tmp = u1tmp = u0 = u1 = deltaTmp = 0;
		for (int j = 0; j < GrayScale; j++) {
			if (j <= i) {
				w0 += pixPro[j];
				u0tmp += j * pixPro[j];
			} else {
				w1 += pixPro[j];
				u1tmp += j * pixPro[j];
			}
		}
		u0 = u0tmp / w0;
		u1 = u1tmp / w1;
		deltaTmp = (float)(w0 * w1 * pow((u0 - u1), 2)); //��䷽�ʽ g = w1 * w2 * (u1 - u2) ^ 2
		if (deltaTmp > deltaMax) {
			deltaMax = deltaTmp;
			th = i;
		}
	}
	return th;
}

CImg<unsigned char> Cut::background(CImg<unsigned char> input) {
	CImg<unsigned char> result = toGrayScale(input);
	int th = getThreshold(input);
	cout << th << endl;
	cimg_forXY(result, x, y) {
		if (result(x, y) > th) {
			result(x, y) = 255;
		} 
		else {
			result(x, y) = 0;
		}
	}
	return result;
}

CImg<unsigned char> Cut::toGrayScale(CImg<unsigned char> input) {
	CImg<unsigned char> grayscaled = CImg<unsigned char>(input._width, input._height);
	cimg_forXY(input, x, y) {
		int b = input(x, y, 0);
		int g = input(x, y, 1);
		int r = input(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	return grayscaled;
}

CImg<unsigned char> Cut::delate(CImg<unsigned char> input) {
	int size = 3;
	CImg<unsigned char> output = CImg<unsigned char>(input._width, input._height);
	for (int i = size / 2; i < output._width - size / 2; i++) {
		for (int j = size / 2; j < output._height - size / 2; j++) {
			int m = 255;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					if (input(i + x - size / 2, j + y - size / 2) < m) {
						m = input(i + x - size / 2, j + y - size / 2);
					}
				}
			}
			output(i, j) = m;
		}
	}
	return output;
}

void Cut::dfs(int x, int y, vector<Point> &tmp) {
	if (x < 0 || x >= delate_img._width || 
		y < 0 || y >= delate_img._height || 
		visit[y * delate_img._width + x] ||
		delate_img(x, y) != 0)
		return;

	Point tmpp = Point(x, y);
	tmp.push_back(tmpp);
	visit[y * delate_img._width + x] = true;

	for (int i = -1; i < 2; i++) {
		for (int j = -1; j < 2; j++) {
			if (i != 0 || j != 0) {
				dfs(x + i, y + j, tmp);
			}
		}
	}
}

void Cut::find_connection() {
	cimg_forXY(delate_img, x, y) {
		if (delate_img(x, y) == 0 && visit[y * delate_img._width + x] == false) {
			vector<Point> tmp;
			dfs(x, y, tmp);
			connect.push_back(tmp);
		}
	}
}

CImg<unsigned char>  Cut::draw(CImg<unsigned char> input){
	CImg<unsigned char> result = input;
	const unsigned char red[] = { 255,0,0 };

	for (int i = 0; i < connect.size(); i++) {
		if (connect[i].size() >= 80 && connect[i].size()<=250) {
			int xmin = delate_img._width, xmax = 0;
			int ymin = delate_img._height, ymax = 0;

			for (int j = 0; j < connect[i].size(); j++) {
				xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
				xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
				ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
				ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
			}

			result.draw_line(xmin, ymin, xmax, ymin, red);
			result.draw_line(xmin, ymax, xmax, ymax, red);
			result.draw_line(xmin, ymin, xmin, ymax, red);
			result.draw_line(xmax, ymin, xmax, ymax, red);
		}
	}
	return result;
}

CImg<unsigned char> Cut::find_ruler(CImg<unsigned char> input) {
	CImg<unsigned char> result = origin_img;
	const unsigned char blue[] = { 0,0,255 };
	float max_scale = 0;
	int rx0=0, ry0=0, rx1=0, ry1=0;

	for (int i = 0; i < connect.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;

		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}

		float tmp_scale = (xmax - xmin)/ (ymax - ymin);
		if (tmp_scale > max_scale) {
			max_scale = tmp_scale;
			rx0 = xmin;
			rx1 = xmax;
			ry0 = ymin;
			ry1 = ymax;
		}		
	}
	ry0 -= 10;
	ry1 += 30;

	ruler_pos.push_back(rx0);
	ruler_pos.push_back(rx1);
	ruler_pos.push_back(ry0);
	ruler_pos.push_back(ry1);

	result.draw_line(rx0, ry0, rx1, ry0, blue);
	result.draw_line(rx0, ry1, rx1, ry1, blue);
	result.draw_line(rx0, ry0, rx0, ry1, blue);
	result.draw_line(rx1, ry0, rx1, ry1, blue);
	return result;
}

void Cut::knn() {
	string dir = "train_cut12x16/";
	string img_name = dir;

	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;

	for (int i = 0; i < 10; i++) {
		string tmp_dir = dir + to_string(i) + "/" + to_string(i) + "_";
		for (int j = 0; j < 1000; j++) {
			img_name = tmp_dir + to_string(j) + ".png";
			cout << img_name << endl;
			Mat srcimage = imread(img_name);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);

	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);

	for (int i = 0; i < connect.size(); i++) {
		if (connect[i].size() < 80 || connect[i].size() > 250) continue;
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;

		vector<Point> tmp;
		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}

		if (xmin > ruler_pos[0] && xmax < ruler_pos[1] &&
			ymin > ruler_pos[2] && ymax < ruler_pos[3]) {
			tmp.push_back(Point(xmin, ymin));
			tmp.push_back(Point(xmax, ymax));
			number.push_back(tmp);
		}
	}

	for (int i = 0; i < number.size(); i++) {
		Rect rect(number[i][0].x-1, number[i][0].y-1, number[i][1].x - number[i][0].x+2, number[i][1].y - number[i][0].y+2);
		Mat testdata = origin_img_cv(rect);
		resize(testdata, testdata, Size(12, 16));
		testdata = testdata.reshape(1, 1);
		testdata.convertTo(testdata, CV_32F);
		int response = knn->predict(testdata);
		cout << response << endl;
	}
}