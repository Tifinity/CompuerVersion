#ifndef _CANNY_
#define _CANNY_
#include <string>
#include "CImg.h"

using namespace std;
using namespace cimg_library;

class canny {
private:
	CImg<unsigned char> img; //Original Image
	CImg<unsigned char> grayscaled; // Grayscale
	CImg<unsigned char> gFiltered; // Gradient
	CImg<unsigned char> sFiltered; //Sobel Filtered
	CImg<unsigned char> angles; //Angle Map
	CImg<unsigned char> non; // Non-maxima supp.
	CImg<unsigned char> thres; //Double threshold and final
	CImg<unsigned char> edge; //Double threshold and final
	CImg<unsigned char> edge2; //Double threshold and final
public:
	canny(string); //Constructor
	CImg<unsigned char> toGrayScale();
	vector<vector<double> > createFilter(int, int, double); //Creates a gaussian filter
	CImg<unsigned char> useFilter(CImg<unsigned char>, vector<vector<double> >); //Use some filter
	CImg<unsigned char> sobel(); //Sobel filtering
	CImg<unsigned char> nonMaxSupp(); //Non-maxima supp.
	CImg<unsigned char> threshold(CImg<unsigned char>, int, int); //Double threshold and finalize picture
	CImg<unsigned char> Dilate(CImg<unsigned char> imgIn);
	CImg<unsigned char> Corrosion(CImg<unsigned char> imgIn);
	CImg<unsigned char> edgeTreatment(CImg<unsigned char> Ex, int distance);
};

#endif
