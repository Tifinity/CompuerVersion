//
//  main.cpp
//  Canny Edge Detector
//
//  Created by Hasan Akgün on 21/03/14.
//  Copyright (c) 2014 Hasan Akgün. All rights reserved.
//

#include <iostream>
#define _USE_MATH_DEFINES
#include <cmath>
#include <vector>
#include "canny.h"

using namespace std;

int main() {
	char path[5][99] = {"4.bmp"}; //Filepath of input image
	for (int i = 0; i < 5; i++) {
		canny res(path[i]);
	}
	return 0;
}

