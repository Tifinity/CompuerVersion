#include <iostream>
#define _USE_MATH_DEFINES
#include <cmath>
#include <vector>
#include "canny.h"

using namespace std;
using namespace cimg_library;

canny::canny(string filename) {
	CImg<unsigned char> temp(filename.c_str());
	img = temp;
	if (!img._data) cout << "Could not open or find the image" << std::endl;
	else {
		vector<vector<double>> filter = createFilter(3, 3, 5);
		for (int i = 0; i<filter.size(); i++) {
			for (int j = 0; j<filter[i].size(); j++) {
				cout << filter[i][j] << " ";
			}
		}
		grayscaled = toGrayScale(); //Grayscale the image
		grayscaled.save("./4/GrayScaled.bmp");
		gFiltered = useFilter(grayscaled, filter); //Gaussian Filter
		gFiltered.save("./4/Gaussian Blur.bmp");
		sFiltered = sobel(); //Sobel Filter
		sFiltered.save("./4/Sobel Filtered.bmp");
		non = nonMaxSupp(); //Non-Maxima Suppression
		non.save("./4/Non-Maxima Supp.bmp");
		thres = threshold(non, 45, 80); //Double Threshold and Finalize
		thres.save("./4/Threshold.bmp");
		edge = Dilate(thres);
		edge2 = Corrosion(thres);
		img.display("Original");
		
		grayscaled.display("GrayScaled");
		
		gFiltered.display("Gaussian Blur");
		sFiltered.display("Sobel Filtered");
		non.display("Non-Maxima Supp");
		//(sFiltered,non).display("Sobel Filtered");
		thres.display("Threshold");
		(thres,edge,edge2).display("Final");
	}
}

//得到灰度图像
CImg<unsigned char> canny::toGrayScale() {
	grayscaled = CImg<unsigned char>(img._width, img._height);
	cimg_forXY(img, x, y) {
		int b = img(x, y, 0);
		int g = img(x, y, 1);
		int r = img(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	return grayscaled;
}

vector<vector<double>> canny::createFilter(int row, int column, double sigmaIn) {
	vector<vector<double>> filter(row, vector<double>(column, -1));
	float coordSum = 0;
	float constant = 2.0 * sigmaIn * sigmaIn;
	// Sum is for normalization
	float sum = 0.0;
	for (int x = -row / 2; x <= row / 2; x++) {
		for (int y = -column / 2; y <= column / 2; y++) {
			coordSum = (x * x + y * y);
			filter[x + row / 2][y + column / 2] = (exp(-(coordSum) / constant)) / (M_PI * constant);
			sum += filter[x + row / 2][y + column / 2];
		}
	}
	// Normalize the Filter
	for (int i = 0; i < row; i++)
		for (int j = 0; j < column; j++)
			filter[i][j] /= sum;
	return filter;
}

CImg<unsigned char> canny::useFilter(CImg<unsigned char> img_in, vector<vector<double>> filterIn) {
	int size = (int)filterIn.size() / 2;
	CImg<unsigned char> filteredImg = CImg<unsigned char>(img_in._width - 2 * size, img_in._height - 2 * size, 1);
	for (int i = size; i < img_in._width - size; i++) {
		for (int j = size; j < img_in._height - size; j++) {
			double sum = 0;
			for (int x = 0; x < filterIn.size(); x++)
				for (int y = 0; y < filterIn.size(); y++) {
					sum += filterIn[x][y] * (double)(img_in(i + x - size, j + y - size));
				}
			filteredImg(i - size, j - size) = sum;
		}
	}
	return filteredImg;
}

CImg<unsigned char> canny::sobel() {
    //Sobel X Filter
    double x1[] = {-1.0, 0, 1.0};
    double x2[] = {-2.0, 0, 2.0};
    double x3[] = {-1.0, 0, 1.0};
    vector<vector<double>> xFilter(3);
    xFilter[0].assign(x1, x1+3);
    xFilter[1].assign(x2, x2+3);
    xFilter[2].assign(x3, x3+3);
    //Sobel Y Filter
    double y1[] = {1.0, 2.0, 1.0};
    double y2[] = {0, 0, 0};
    double y3[] = {-1.0, -2.0, -1.0};
    vector<vector<double>> yFilter(3);
    yFilter[0].assign(y1, y1+3);
    yFilter[1].assign(y2, y2+3);
    yFilter[2].assign(y3, y3+3);
    //Limit Size
    int size = (int)xFilter.size()/2;
	CImg<unsigned char> filteredImg = CImg<unsigned char>(gFiltered._width - 2 * size, gFiltered._height - 2 * size);
    angles = CImg<unsigned char>(gFiltered._width - 2 * size, gFiltered._height - 2 * size, 1); //AngleMap
	//防止越界
	for (int i = size; i < gFiltered._width - size; i++) {
		for (int j = size; j < gFiltered._height - size; j++) {
			double sumx = 0;
            double sumy = 0;        
			for (int x = 0; x < xFilter.size(); x++) {
				for (int y = 0; y < xFilter.size(); y++) {
					sumx += xFilter[x][y] * (double)(gFiltered(i + x - size, j + y - size)); //Sobel_X Filter Value
					sumy += yFilter[x][y] * (double)(gFiltered(i + x - size, j + y - size)); //Sobel_Y Filter Value
				}
			}
            double sumxsq = sumx * sumx;
            double sumysq = sumy * sumy;
            double sq2 = sqrt(sumxsq + sumysq);
            if(sq2 > 255) sq2 =255;//Unsigned Char Fix
            filteredImg(i-size, j-size) = sq2;
            if(sumx==0) angles(i-size, j-size) = 90;//Arctan Fix
            else angles(i-size, j-size) = atan(sumy/sumx);
		}
	}
    return filteredImg;
}


CImg<unsigned char> canny::nonMaxSupp() {
	CImg<unsigned char> nonMaxSupped = CImg<unsigned char>(sFiltered._width - 2, sFiltered._height - 2);
    for (int i=1; i< sFiltered._width - 1; i++) {
        for (int j=1; j<sFiltered._height - 1; j++) {
            float Tangent = angles(i,j);
            nonMaxSupped(i-1, j-1) = sFiltered(i,j);
            //Horizontal Edge
            if (((-22.5 < Tangent) && (Tangent <= 22.5)) || ((157.5 < Tangent) && (Tangent <= -157.5))) {
                if ((sFiltered(i,j) < sFiltered(i,j+1)) || (sFiltered(i,j) < sFiltered(i,j-1)))
                    nonMaxSupped(i-1, j-1) = 0;
            }
            //Vertical Edge
            if (((-112.5 < Tangent) && (Tangent <= -67.5)) || ((67.5 < Tangent) && (Tangent <= 112.5))) {
                if ((sFiltered(i,j) < sFiltered(i+1,j)) || (sFiltered(i,j) < sFiltered(i-1,j)))
                    nonMaxSupped(i-1, j-1) = 0;
            }
            
            //-45 Degree Edge
            if (((-67.5 < Tangent) && (Tangent <= -22.5)) || ((112.5 < Tangent) && (Tangent <= 157.5))) {
                if ((sFiltered(i,j) < sFiltered(i-1,j+1)) || (sFiltered(i,j) < sFiltered(i+1,j-1)))
                    nonMaxSupped(i-1, j-1) = 0;
            }
            
            //45 Degree Edge
            if (((-157.5 < Tangent) && (Tangent <= -112.5)) || ((22.5 < Tangent) && (Tangent <= 67.5))) {
                if ((sFiltered(i,j) < sFiltered(i+1,j+1)) || (sFiltered(i,j) < sFiltered(i-1,j-1)))
                    nonMaxSupped(i-1, j-1) = 0;
            }
        }
    }
    return nonMaxSupped;
}

CImg<unsigned char> canny::threshold(CImg<unsigned char> imgin, int low, int high) {
    if(low > 255) low = 255;
    if(high > 255) high = 255;
	CImg<unsigned char> EdgeMat = CImg<unsigned char>(imgin._width, imgin._height);
    for (int i=0; i<imgin._width; i++) {
        for (int j = 0; j<imgin._height; j++) {
            EdgeMat(i,j) = imgin(i,j);
            if(EdgeMat(i,j) > high) EdgeMat(i,j) = 255;
            else if(EdgeMat(i,j) < low) EdgeMat(i,j) = 0;
			else {
				bool anyHigh = false;
				bool anyBetween = false;
				for (int x = i - 1; x < i + 2; x++) {
					for (int y = j - 1; y < j + 2; y++) {
						if (x <= 0 || y <= 0 || EdgeMat._width || y > EdgeMat._height) //Out of bounds
							continue;
						else{
							if (EdgeMat(x, y) > high) {
								EdgeMat(i, j) = 255;
								anyHigh = true;
								break;
							}
							else if (EdgeMat(x, y) <= high && EdgeMat(x, y) >= low)
								anyBetween = true;
						}
					}
					if (anyHigh) break;
				}
				if (!anyHigh && anyBetween)
					for (int x = i - 2; x < i + 3; x++) {
						for (int y = j - 1; y < j + 3; y++) {
							if (x < 0 || y < 0 || x > EdgeMat._width || y > EdgeMat._height) //Out of bounds
								continue;
							else {
								if (EdgeMat(x, y) > high) {
									EdgeMat(i, j) = 255;
									anyHigh = true;
									break;
								}
							}
						}
						if (anyHigh) break;
					}
				if (!anyHigh) EdgeMat(i, j) = 0;
			}
        }
    }
    return EdgeMat;
}

CImg<unsigned char> canny::Dilate(CImg<unsigned char> imgIn) {
	int size = 2;
	CImg<unsigned char> imgOut = CImg<unsigned char>(thres._width, thres._height);
	for (int i = size/2; i < imgOut._width - size/2; i++) {
		for (int j = size/2; j < imgOut._height - size/2; j++) {
			int m = 0;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					if (imgIn(i+x-size/2,j+y-size/2) > m) {
						m = imgIn(i + x - size / 2, j + y - size / 2);
					}
				}
			}
			imgOut(i, j) = m;
		}
	}
	return imgOut;
}

CImg<unsigned char> canny::Corrosion(CImg<unsigned char> imgIn) {
	int size = 2;
	int s[2][2] = { 1,1,1,1 };
	CImg<unsigned char> imgOut = CImg<unsigned char>(imgIn._width, imgIn._height);
	for (int i = size / 2; i < imgOut._width - size / 2; i++) {
		for (int j = size / 2; j < imgOut._height - size / 2; j++) {
			int m = 0;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					if (s[x][y] == 1 && imgIn(i + x - size / 2, j + y - size / 2) == 0) {
						m++;
					}
				}
			}
			if(m==2) imgOut(i, j) = (unsigned char)255;
		}
	}
	return imgOut;
}


CImg<unsigned char> canny::edgeTreatment(CImg<unsigned char> Ex, int distance) {
	CImg<unsigned char> E = Ex;
	bool isEdge[1000][1000];
	cimg_forXY(E, x, y) {
		isEdge[x][y] = false;
		if (x != E.width() - 1 && x != 0 && y != E.height() - 1 && y != 0 && E(x, y) == 255) {
			int neighborhood[8];
			int m = 0;
			for (int i = x - 1; i <= x + 1; i++) {
				for (int j = y - 1; j <= y + 1; j++) {
					if (!(i == x && j == y)) {
						neighborhood[m] = E(i, j);
						m++;
					}
				}
			}
			sort(neighborhood, neighborhood + 8);
			if (neighborhood[6] == 0 && neighborhood[7] == 255)
				isEdge[x][y] = true;
		}
	}
	
	cimg_forXY(E, x, y) {
		if (x >= distance && y >= distance && x <= E.width() - 1 - distance && y <= E.height() - 1 - distance && isEdge[x][y] == true) {
			for (int i = x - distance; i <= x + distance; i++) {
				for (int j = y - distance; j <= y + distance; j++) {
					if (isEdge[i][j] == true) {
						int white[] = { 255,255,255 };
						E.draw_line(x, y, i, j, white);
						isEdge[i][j] = false;
						isEdge[x][y] = false;
					}
				}
			}
		}
	}
	
	cimg_forXY(E, x, y) {
		isEdge[x][y] = false;
		if (x != E.width() - 1 && x != 0 && y != E.height() - 1 && y != 0 && E(x, y) == 255) {
			int neighborhood[8];
			int m = 0;
			for (int i = x - 1; i <= x + 1; i++) {
				for (int j = y - 1; j <= y + 1; j++) {
					if (!(i == x && j == y)) {
						neighborhood[m] = E(i, j);
						m++;
					}
				}
			}
			sort(neighborhood, neighborhood + 8);
			if (neighborhood[6] == 0 && neighborhood[7] == 255)
				isEdge[x][y] = true;
			if (neighborhood[7] == 0)
				E(x, y) = 0;
		}
	}
	cimg_forXY(E, x, y) {
		int distance = 20;
		if (isEdge[x][y] == true) {
			for (int i = (x - distance > 0 ? x - distance : 0); i <= (x + distance < E.width() - 1 ? x + distance : E.width() - 1); i++) {
				for (int j = (y - distance > 0 ? y - distance : 0); j <= (y + distance < E.height() - 1 ? y + distance : E.height() - 1); j++) {
					if (isEdge[i][j] == true) {
						for (int k = (x >= i ? i : x); k <= (x >= i ? x : i); k++) {
							for (int r = (y >= j ? j : y); r <= (y >= j ? y : j); r++) {
								E(k, r) = 0;
							}
						}
						isEdge[i][j] = false;
						isEdge[x][y] = false;
					}
				}
			}
		}
	}
	//delete single points again
	cimg_forXY(E, x, y) {
		if (x != E.width() - 1 && x != 0 && y != E.height() - 1 && y != 0 && E(x, y) == 255) {
			int neighborhood[8];
			int m = 0;
			for (int i = x - 1; i <= x + 1; i++) {
				for (int j = y - 1; j <= y + 1; j++) {
					if (!(i == x && j == y)) {
						neighborhood[m] = E(i, j);
						m++;
					}
				}
			}
			sort(neighborhood, neighborhood + 8);
			if (neighborhood[7] == 0)
				E(x, y) = 0;
		}
	}
	return E;
}