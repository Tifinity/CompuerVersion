#include "Cut.h"
#include <sstream>

using namespace std;

Cut::Cut(string filename) {
	origin_img_cv = imread(filename);
	CImg<unsigned char> tmp(filename.c_str());
	origin_img = tmp;
	if (!origin_img.data()) {
		cout << "Could not open or find the image" << std::endl;
		exit(-1);
	}

	visit = new bool[origin_img._width * origin_img._height];
	for (int i = 0; i < origin_img._width * origin_img._height; i++)
		visit[i] = false;

	origin_img.display("origin image");
	gray_img = toGrayScale(origin_img);
	// gray_img.display("gray_img image");
	delate_img = delate(gray_img);
	delate_img.display("delate image");
	find_connection();
	process_connection();
	
	//result_img = draw_red(origin_img);
	//result_img = draw_blue(origin_img);
	result_img = draw_green(origin_img);
	result_img.display("result image");

	//knn_red();
	//knn_blue();
	knn_green();
	result_img = find_brackets(origin_img);
	result_img.display("result image");
}

Cut::~Cut() {
	delete[]visit;
}

int Cut::getThreshold(CImg<unsigned char> src) {
	int th;
	const int GrayScale = 256;	//��ͨ��ͼ���ܻҶ�256��
	int pixCount[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ���ظ���
	int pixSum = src._width * src._height;//ͼ�������ص�
	float pixPro[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ�����ر���
	float w0, w1, u0tmp, u1tmp, u0, u1, deltaTmp, deltaMax = 0;

	cimg_forXY(src, x, y) {
		pixCount[src(x, y)]++;//ͳ��ÿ���Ҷȼ������صĸ���
	}

	for (int i = 0; i < GrayScale; i++) {
		pixPro[i] = pixCount[i] * 1.0 / pixSum;//����ÿ���Ҷȼ���������Ŀռ����ͼ��ı���  
	}
	//�������д�0��255�Ҷȼ�����ֵ�ָ�������������һ������䷽�����
	for (int i = 0; i < GrayScale; i++) {
		w0 = w1 = u0tmp = u1tmp = u0 = u1 = deltaTmp = 0;
		for (int j = 0; j < GrayScale; j++) {
			if (j <= i) {
				w0 += pixPro[j];
				u0tmp += j * pixPro[j];
			} else {
				w1 += pixPro[j];
				u1tmp += j * pixPro[j];
			}
		}
		u0 = u0tmp / w0;
		u1 = u1tmp / w1;
		deltaTmp = (float)(w0 * w1 * pow((u0 - u1), 2)); //��䷽�ʽ g = w1 * w2 * (u1 - u2) ^ 2
		if (deltaTmp > deltaMax) {
			deltaMax = deltaTmp;
			th = i;
		}
	}
	return th;
}

CImg<unsigned char> Cut::background(CImg<unsigned char> input) {
	CImg<unsigned char> result = toGrayScale(input);
	int th = getThreshold(input);
	cout << th << endl;
	cimg_forXY(result, x, y) {
		if (result(x, y) > th) {
			result(x, y) = 255;
		} 
		else {
			result(x, y) = 0;
		}
	}
	return result;
}

CImg<unsigned char> Cut::toGrayScale(CImg<unsigned char> input) {
	CImg<unsigned char> grayscaled = CImg<unsigned char>(input._width, input._height);
	cimg_forXY(input, x, y) {
		int b = input(x, y, 0);
		int g = input(x, y, 1);
		int r = input(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	cimg_forXY(grayscaled, x, y) {
		if (grayscaled(x, y) < 120) {
			grayscaled(x, y) = 0;
		}
		else {
			grayscaled(x, y) = 255;
		}
	}
	return grayscaled;
}

CImg<unsigned char> Cut::delate(CImg<unsigned char> input) {
	int size = 3;
	CImg<unsigned char> output = CImg<unsigned char>(input._width, input._height);
	for (int i = size / 2; i < output._width - size / 2; i++) {
		for (int j = size / 2; j < output._height - size / 2; j++) {
			int m = 255;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					if (input(i + x - size / 2, j + y - size / 2) < m) {
						m = input(i + x - size / 2, j + y - size / 2);
					}
				}
			}
			output(i, j) = m;
		}
	}
	return output;
}

void Cut::dfs(int x, int y, vector<Point> &tmp) {
	if (x < 0 || x >= delate_img._width || 
		y < 0 || y >= delate_img._height || 
		visit[y * delate_img._width + x] ||
		delate_img(x, y) != 0)
		return;

	Point tmpp = Point(x, y);
	tmp.push_back(tmpp);
	visit[y * delate_img._width + x] = true;

	for (int i = -1; i < 2; i++) {
		for (int j = -1; j < 2; j++) {
			if (i != 0 || j != 0) {
				dfs(x + i, y + j, tmp);
			}
		}
	}
}

void Cut::find_connection() {
	cimg_forXY(delate_img, x, y) {
		if (delate_img(x, y) == 0 && visit[y * delate_img._width + x] == false) {
			vector<Point> tmp;
			dfs(x, y, tmp);
			connect.push_back(tmp);
		}
	}
}

bool mycmpx(vector<int> a, vector<int> b) {
	return a[0] < b[0];
}
bool mycmpy(vector<int> a, vector<int> b) {
	return a[2] < b[2];
}

void Cut::process_connection() {
	for (int i = 0; i < connect.size(); i++) {
		vector<int> tmp;
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		if (connect[i].size() >= 80 && connect[i].size() <= 350) {
			for (int j = 0; j < connect[i].size(); j++) {
				xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
				xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
				ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
				ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
			}
			tmp.push_back(xmin);
			tmp.push_back(xmax);
			tmp.push_back(ymin);
			tmp.push_back(ymax);
			number.push_back(tmp);
		}
	}
}

CImg<unsigned char>  Cut::draw_red(CImg<unsigned char> input){
	CImg<unsigned char> result = input;
	const unsigned char red[] = { 255,0,0 };
	int xmin = delate_img._width, xmax = 0;
	int ymin = delate_img._height, ymax = 0;
	/*1*/
	//ymin = 119;
	//ymax = 183;
	/*2*/
	//ymin = 47;
	//ymax = 115;
	/*3*/
	ymin = 23;
	ymax = 139;
	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			red_number.push_back(number[i]);
		}
	}

	red_pos.push_back(xmin - 1);
	red_pos.push_back(xmax + 1);
	red_pos.push_back(ymin - 1);
	red_pos.push_back(ymax + 1);
	result.draw_line(red_pos[0], red_pos[2], red_pos[1], red_pos[2], red);
	result.draw_line(red_pos[0], red_pos[3], red_pos[1], red_pos[3], red);
	result.draw_line(red_pos[0], red_pos[2], red_pos[0], red_pos[3], red);
	result.draw_line(red_pos[1], red_pos[2], red_pos[1], red_pos[3], red);
	/*
	for (int i = 0; i < red_number.size(); i++) {
		result.draw_line(red_number[i][0], red_number[i][2], red_number[i][1], red_number[i][2], red);
		result.draw_line(red_number[i][0], red_number[i][3], red_number[i][1], red_number[i][3], red);
		result.draw_line(red_number[i][0], red_number[i][2], red_number[i][0], red_number[i][3], red);
		result.draw_line(red_number[i][1], red_number[i][2], red_number[i][1], red_number[i][3], red);
	}
	*/
	sort(red_number.begin(), red_number.end(), mycmpx);
	int tmpy = red_number[0][0];
	int i = 0;
	vector<vector<int>> tmp;
	while (i < red_number.size()) {
		if (abs(red_number[i][0] - tmpy) > 2) {
			number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(red_number[i]);
		tmpy = red_number[i][0];
		i++;
	}
	number2.push_back(tmp);

	for (int i = 0; i < number2.size(); i++) {
		sort(number2[i].begin(), number2[i].end(), mycmpy);
		
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;

		for (int j = 0; j < number2[i].size(); j++) {
			xmin = number2[i][j][0] < xmin ? number2[i][j][0] : xmin;
			xmax = number2[i][j][1] > xmax ? number2[i][j][1] : xmax;
			ymin = number2[i][j][2] < ymin ? number2[i][j][2] : ymin;
			ymax = number2[i][j][3] > ymax ? number2[i][j][3] : ymax;
		}

		result.draw_line(xmin, ymin, xmax, ymin, red);
		result.draw_line(xmin, ymax, xmax, ymax, red);
		result.draw_line(xmin, ymin, xmin, ymax, red);
		result.draw_line(xmax, ymin, xmax, ymax, red);
	}
	return result;
}

CImg<unsigned char>  Cut::draw_blue(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char blue[] = { 0,0,255 };
	int xmin = delate_img._width, xmax = 0;
	/*1*/
	//int ymin = 1400;
	//int ymax = 1430;
	/*2*/
	//int ymin = 1322;
	//int ymax = 1347;
	/*3*/
	int ymin = 1307;
	int ymax = 1348; 

	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			blue_number.push_back(number[i]);
		}
	}

	blue_pos.push_back(xmin - 1);
	blue_pos.push_back(xmax + 1);
	blue_pos.push_back(ymin - 1);
	blue_pos.push_back(ymax + 1);
	result.draw_line(blue_pos[0], blue_pos[2], blue_pos[1], blue_pos[2], blue);
	result.draw_line(blue_pos[0], blue_pos[3], blue_pos[1], blue_pos[3], blue);
	result.draw_line(blue_pos[0], blue_pos[2], blue_pos[0], blue_pos[3], blue);
	result.draw_line(blue_pos[1], blue_pos[2], blue_pos[1], blue_pos[3], blue);
	
	sort(blue_number.begin(), blue_number.end(), mycmpx);
	int tmpy = blue_number[0][0];
	int i = 0;
	vector<vector<int>> tmp;

	while (i < blue_number.size()) {
		/*1-50 2-25 3-43*/
		if (abs(blue_number[i][0] - tmpy) > 43) {
			number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(blue_number[i]);
		tmpy = blue_number[i][0];
		i++;
	}
	number2.push_back(tmp);

	for (int i = 0; i < number2.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		for (int j = 0; j < number2[i].size(); j++) {
			xmin = number2[i][j][0] < xmin ? number2[i][j][0] : xmin;
			xmax = number2[i][j][1] > xmax ? number2[i][j][1] : xmax;
			ymin = number2[i][j][2] < ymin ? number2[i][j][2] : ymin;
			ymax = number2[i][j][3] > ymax ? number2[i][j][3] : ymax;
		}
		result.draw_line(xmin, ymin, xmax, ymin, blue);
		result.draw_line(xmin, ymax, xmax, ymax, blue);
		result.draw_line(xmin, ymin, xmin, ymax, blue);
		result.draw_line(xmax, ymin, xmax, ymax, blue);
	}
	return result;
}

CImg<unsigned char>  Cut::draw_green(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char green[] = { 0,255,0 };
	int xmin = delate_img._width, xmax = 0;
	/*1*/
	int ymin = 1461;
	int ymax = 1498;
	/*2*/
	// ymin = 1241;
	//int ymax = 1296;
	/*3*/
	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			green_number.push_back(number[i]);
		}
	}
	green_pos.push_back(xmin - 2);
	green_pos.push_back(xmax + 2);
	green_pos.push_back(ymin - 2);
	green_pos.push_back(ymax + 2);
	result.draw_line(green_pos[0], green_pos[2], green_pos[1], green_pos[2], green);
	result.draw_line(green_pos[0], green_pos[3], green_pos[1], green_pos[3], green);
	result.draw_line(green_pos[0], green_pos[2], green_pos[0], green_pos[3], green);
	result.draw_line(green_pos[1], green_pos[2], green_pos[1], green_pos[3], green);
	
	sort(green_number.begin(), green_number.end(), mycmpx);
	int tmpx = green_number[0][0];
	int tmpy = green_number[0][2];
	int i = 0;
	vector<vector<int>> tmp;
	while (i < green_number.size()) {
		/*1*/
		//abs(green_number[i][2] - tmpy) > 2 || abs(green_number[i][0] - tmpx) > 30
		/*2*/
		//abs(green_number[i][0] - tmpx) > 30
		/*3*/
		if (abs(green_number[i][2] - tmpy) > 2 || abs(green_number[i][0] - tmpx) > 30) {
			number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(green_number[i]);
		tmpx = green_number[i][0];
		tmpy = green_number[i][2];
		i++;
	}
	number2.push_back(tmp);
	for (int i = 0; i < number2.size(); i++) {
		sort(number2[i].begin(), number2[i].end(), mycmpy);
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		for (int j = 0; j < number2[i].size(); j++) {
			xmin = number2[i][j][0] < xmin ? number2[i][j][0] : xmin;
			xmax = number2[i][j][1] > xmax ? number2[i][j][1] : xmax;
			ymin = number2[i][j][2] < ymin ? number2[i][j][2] : ymin;
			ymax = number2[i][j][3] > ymax ? number2[i][j][3] : ymax;
		}
		result.draw_line(xmin, ymin, xmax, ymin, green);
		result.draw_line(xmin, ymax, xmax, ymax, green);
		result.draw_line(xmin, ymin, xmin, ymax, green);
		result.draw_line(xmax, ymin, xmax, ymax, green);
	}
	return result;
}

CImg<unsigned char> Cut::find_ruler(CImg<unsigned char> input) {
	CImg<unsigned char> result = origin_img;
	const unsigned char blue[] = { 0,0,255 };
	float max_scale = 0;
	int rx0=0, ry0=0, rx1=0, ry1=0;

	for (int i = 0; i < connect.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;

		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}

		float tmp_scale = (xmax - xmin)/ (ymax - ymin);
		if (tmp_scale > max_scale) {
			max_scale = tmp_scale;
			rx0 = xmin;
			rx1 = xmax;
			ry0 = ymin;
			ry1 = ymax;
		}		
	}
	ry0 -= 10;
	ry1 += 30;

	ruler_pos.push_back(rx0);
	ruler_pos.push_back(rx1);
	ruler_pos.push_back(ry0);
	ruler_pos.push_back(ry1);

	result.draw_line(rx0, ry0, rx1, ry0, blue);
	result.draw_line(rx0, ry1, rx1, ry1, blue);
	result.draw_line(rx0, ry0, rx0, ry1, blue);
	result.draw_line(rx1, ry0, rx1, ry1, blue);
	return result;
}

CImg<unsigned char> Cut::find_brackets(CImg<unsigned char> input) {
	CImg<unsigned char> result = origin_img;
	const unsigned char red[] = { 255,0,0 };

	for (int i = 0; i < connect.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		vector<int> tmp;
		
		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}
		float tmp_scale = (xmax - xmin) / (ymax - ymin);
		/*1*/
		//ymin >= 1400 && ymax <= 1461 && tmp_scale > 2
		/*2*/
		//ymin >= 1223 && ymax <= 1246 && tmp_scale > 1
		if (ymin >= 1400 && ymax <= 1461 && tmp_scale > 2) {
			tmp.push_back(xmin);
			tmp.push_back(xmax);
			tmp.push_back(ymin);
			tmp.push_back(ymax);
			bracket.push_back(tmp);
		}
	}
	
	sort(bracket.begin(), bracket.end(), mycmpx);
	for (int i = 0; i < bracket.size(); i++) {
		result.draw_line(bracket[i][0], bracket[i][2], bracket[i][1], bracket[i][2], red);
		result.draw_line(bracket[i][0], bracket[i][3], bracket[i][1], bracket[i][3], red);
		result.draw_line(bracket[i][0], bracket[i][2], bracket[i][0], bracket[i][3], red);
		result.draw_line(bracket[i][1], bracket[i][2], bracket[i][1], bracket[i][3], red);
	}

	for (int i = 0; i < bracket.size(); i++) {
		/*1*/
		float tmpleft = 0.6 + (2056 - bracket[i][0]) * 0.1 / 37;
		float tmpright = tmpleft - (bracket[i][1] - bracket[i][0]) * 0.1 / 37;
		/*2*/
		//float tmpleft = (2207 - bracket[i][0]) * 0.2 / 54;
		//float tmpright = tmpleft - (bracket[i][1] - bracket[i][0]) * 0.2 / 54;
		/*3*/
		
		cout << tmpleft << " " << tmpright << endl;
		
		int tmpx = bracket[i][0];
		for (int i = 0; i < number2.size(); i++) {
			if (abs(number2[i][0][0] - tmpx) < 40) {
				cout << knn_number[i] << endl;
			}
		}
	}
	return result;
}

void Cut::knn_red() {
	string dir = "train_cut12x16/";
	string img_name = dir;

	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;

	for (int i = 0; i < 10; i++) {
		string tmp_dir = dir + to_string(i) + "/" + to_string(i) + "_";
		for (int j = 0; j < 1000; j++) {
			img_name = tmp_dir + to_string(j) + ".png";
			cout << img_name << endl;
			Mat srcimage = imread(img_name);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);

	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);

	for (int i = 0; i < number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < number2[i].size(); j++) {
			string tmp = "";
			//cout << number2[i][0] << " " << number2[i][1] << " " << number2[i][2] << number2[i][3] << endl;
			Rect rect(number2[i][j][0] - 1, number2[i][j][2] - 1, number2[i][j][1] - number2[i][j][0] + 2, number2[i][j][3] - number2[i][j][2] + 2);
			Mat testdata = origin_img_cv(rect);
			
			transpose(testdata, testdata);
			flip(testdata, testdata, 1);
			
			resize(testdata, testdata, Size(12, 16));
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			
			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 2) numstr += '.';
		}
		reverse(numstr.begin(), numstr.end());
		cout << numstr << endl;
	}
}

void Cut::knn_blue() {
	string dir = "train_cut12x16/";
	string img_name = dir;

	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;

	for (int i = 0; i < 10; i++) {
		string tmp_dir = dir + to_string(i) + "/" + to_string(i) + "_";
		for (int j = 0; j < 1000; j++) {
			img_name = tmp_dir + to_string(j) + ".png";
			cout << img_name << endl;
			Mat srcimage = imread(img_name);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);

	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);

	for (int i = 0; i < number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < number2[i].size(); j++) {
			string tmp = "";
			Rect rect(number2[i][j][0] - 1, number2[i][j][2] - 1, number2[i][j][1] - number2[i][j][0] + 2, number2[i][j][3] - number2[i][j][2] + 2);
			Mat testdata = origin_img_cv(rect);
			/*3*/
			/*
			transpose(testdata, testdata);
			flip(testdata, testdata, 1);
			*/
			resize(testdata, testdata, Size(12, 16));
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);

			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 0) numstr += '.';
		}
		cout << numstr << endl;
	}
}

void Cut::knn_green() {
	string dir = "train_cut12x16/";
	string img_name = dir;
	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;
	for (int i = 0; i < 10; i++) {
		string tmp_dir = dir + to_string(i) + "/" + to_string(i) + "_";
		for (int j = 0; j < 1000; j++) {
			img_name = tmp_dir + to_string(j) + ".png";
			cout << img_name << endl;
			Mat srcimage = imread(img_name);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);
	for (int i = 0; i < number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < number2[i].size(); j++) {
			string tmp = "";
			Rect rect(number2[i][j][0] - 1, number2[i][j][2] - 1, number2[i][j][1] - number2[i][j][0] + 2, number2[i][j][3] - number2[i][j][2] + 2);
			Mat tmpdata = origin_img_cv(rect);
			/*2*/
			//transpose(tmpdata, tmpdata);
			//flip(tmpdata, tmpdata, 1);
			
			resize(tmpdata, tmpdata, Size(12, 16));
			Mat testdata = tmpdata.clone();
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 0) numstr += '.';
		}
		/*2*/
		//reverse(numstr.begin(), numstr.end());
		cout << numstr << endl;
		knn_number.push_back(numstr);
	}
}

