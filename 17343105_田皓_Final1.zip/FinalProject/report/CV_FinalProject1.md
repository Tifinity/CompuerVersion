# 计算机视觉-Final Project1

## 任务目标

给定若干张名片图，实现名片的图像校正和名片信息的抽取。

任务可以做如下分解:

1. **名片校正**: 主要是把名片从背景图像中切割出来, 只保留名片本身的完整图像信息(不含背景图等)。

2. **名片主要部分切割**: 对于名片图像, 可以分为如下几个主要的部分: 姓名, Title, 单位信息,电话号码等。

3. **字符切割与识别**: 完成单字符的切割, 并识别, 最后输出(**姓名, Title, 单位信息, 地址，手机, 座机, 传真等号码**)等重要信息。



## 任务一

### 名片校正

> 主要是把名片从背景图像中切割出来, 只保留名片本身的完整图像信息(不含背景图等), 可以采用前面的 Edge+Hough 变换, 或者 Edge+Ransac, 或者 Image Segmentation+Hough 变换。

**具体思路：基于轮廓提取的矫正算法**:

原图：

![image-20191214160300657](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160300657.png)

1. 灰度化

   略

2. 二值化

   略

   ![image-20191214160321817](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160321817.png)

3. 检测轮廓并找到最大轮廓

   使用opencv的`findContours`函数来获得图像内所有轮廓，存放于`vector<vector<Point>> contours`

   ~~~c++
   // 检测所有轮廓
   vector<vector<Point>> contours;
   findContours(bin_img, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
   ~~~

   然后遍历contours找到最大轮廓：

   ~~~C++
   // 找到最大的轮廓即为名片的轮廓
   int max = 0;
   int index = -1;
   for (int i = 0; i < contours.size(); i++) {
       CvPoint2D32f rectpoint[4];
       CvBox2D rect = minAreaRect(Mat(contours[i]));
       cvBoxPoints(rect, rectpoint);
       int line1 = sqrt(
           (rectpoint[1].y - rectpoint[0].y) * (rectpoint[1].y - rectpoint[0].y) + 
           (rectpoint[1].x - rectpoint[0].x) * (rectpoint[1].x - rectpoint[0].x));
       int line2 = sqrt(
           (rectpoint[3].y - rectpoint[0].y) * (rectpoint[3].y - rectpoint[0].y) + 
           (rectpoint[3].x - rectpoint[0].x) * (rectpoint[3].x - rectpoint[0].x));
       if (line1 * line2 > max) {
           max = line1 * line2;
           index = i;
       }
   }
   ~~~

4. 寻找轮廓的包围矩阵，并计算旋转角度

   通过minAreaRect函数得到CvBox2D类型的矩阵，通过cvBoxPoints得到CvPoint2D32f类型的四个顶点。

   ~~~C++
   // 找到一个最小的矩形包围名片
   CvPoint2D32f rectpoint[4];
   CvBox2D rect = minAreaRect(Mat(contours[index]));
   cvBoxPoints(rect, rectpoint);
   // 得到矩阵与水平线的夹角
   float angle = rect.angle;
   // 如果是竖着的在角度上加九十度变成横着的
   int line1 = sqrt(
       (rectpoint[1].y - rectpoint[0].y) * (rectpoint[1].y - rectpoint[0].y) + 
       (rectpoint[1].x - rectpoint[0].x) * (rectpoint[1].x - rectpoint[0].x));
   int line2 = sqrt(
       (rectpoint[3].y - rectpoint[0].y) * (rectpoint[3].y - rectpoint[0].y) + 
       (rectpoint[3].x - rectpoint[0].x) * (rectpoint[3].x - rectpoint[0].x));
   if (line1 > line2) {
       angle = 90 + angle;
   }
   ~~~

5. 旋转图像

   首先通过getRotationMatrix2D得到旋转矩阵，通过warpAffine函数旋转图像。

   ~~~C++
   // 旋转
   Mat RatationedImg(src_img.rows, src_img.cols, CV_8UC3);
   RatationedImg.setTo(0);
   Point2f center = rect.center;
   Mat M2 = getRotationMatrix2D(center, angle, 1);
   warpAffine(src_img, RatationedImg, M2, src_img.size(), 1, 0, Scalar(0));
   my_show(RatationedImg, "rota");
   ~~~

   ![image-20191214160353580](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160353580.png)

6. 将感兴趣区域切割出来，得到结果。

   首先通过之前得到的轮廓画出mask，mask也需要旋转。

   ~~~C++
   // 切割感兴趣区域
   Mat roi_img(src_img.rows, src_img.cols, CV_8UC3);
   Mat roi_mask(src_img.rows, src_img.cols, CV_8UC1);
   roi_img.setTo(0);
   roi_mask.setTo(0);
   drawContours(roi_mask, max_contours, -1, Scalar(255), CV_FILLED);
   warpAffine(roi_mask, roi_mask, M2, src_img.size(), 1, 0, Scalar(0));
   my_show(roi_mask, "mask");
   rotate_img.copyTo(roi_img, roi_mask);
   my_show(roi_img, "roi");
   ~~~

   ![image-20191214160403247](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160403247.png)

   然后使用copyTo函数得到带有黑框的感兴趣区域图像：

   ![image-20191214160454640](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160454640.png)

   再重新找到名片的轮廓使用boundingRect(Mat(contours[index]))作为参数初始化得到最后的结果：

   ~~~C++
   // 在旋转之后的图上重新检测轮廓
   vector<vector<Point>> contours2;
   findContours(roi_mask, contours2, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
   max = 0;
   index = -1;
   for (int i = 0; i < contours2.size(); i++) {
       CvPoint2D32f rectpoint[4];
       CvBox2D rect = minAreaRect(Mat(contours2[i]));
       cvBoxPoints(rect, rectpoint);
       int line1 = sqrt(
           (rectpoint[1].y - rectpoint[0].y) * (rectpoint[1].y - rectpoint[0].y) +
           (rectpoint[1].x - rectpoint[0].x) * (rectpoint[1].x - rectpoint[0].x));
       int line2 = sqrt(
           (rectpoint[3].y - rectpoint[0].y) * (rectpoint[3].y - rectpoint[0].y) +
           (rectpoint[3].x - rectpoint[0].x) * (rectpoint[3].x - rectpoint[0].x));
       if (line1 * line2 > max) {
           max = line1 * line2;
           index = i;
       }
   }
   Mat res_img = roi_img(boundingRect(Mat(contours2[index])));
   my_show(res_img, "res");
   imwrite(output_path, res_img);
   ~~~

   ![image-20191214160735827](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/image-20191214160735827.png)

   到此完成了名片校正的任务。

### 名片主要部分切割

> 对于名片图像, 可以分为如下几个主要的部分: 姓名, Title, 单位信息,电话号码等，这里的方法类似作业 5 的思路。

**具体思路：**

1. 找出连通块；

   使用上次作业的代码即可。

2. 按y值排序；

   ~~~C++
   bool mycmpy(vector<Point> a, vector<Point> b) {
   	return a[0].y < b[0].y;
   }
   ~~~

3. 将每一行连在一起并画出来。

   使用不同颜色画出每一行信息，比较简单。

   ~~~C++
   CImg<unsigned char> Segmentation::draw_info(CImg<unsigned char> input) {
   	CImg<unsigned char> result = input;
   	const unsigned char red[] = { 255,0,0 };
   	const unsigned char green[] = { 0,255,0 };
   	const unsigned char blue[] = { 0,0,255 };
   	const unsigned char yellow[] = { 255,255,0 };
   	const unsigned char r1[] = { 255,0,255 };
   	const unsigned char r2[] = { 0,255,255 };
   
   	sort(connect.begin(), connect.end(), mycmpy);
   	int x0 = origin_img._width, x1 = 0;
   	int y0 = origin_img._height, y1 = 0;
   	int tmpy = Y;
   	int count = 0;
   	for (int i = 0; i < connect.size(); i++) {
   		int xmin = origin_img._width, xmax = 0;
   		int ymin = origin_img._height, ymax = 0;
   		if (connect[i].size() < 50 || connect[i].size() > 15000) continue;
   		for (int j = 0; j < connect[i].size(); j++) {
   			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
   			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
   			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
   			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
   		}	
   		if (abs(ymin - tmpy) > 65) {
   			tmpy = ymin;
   			if (count == 0) {
   				result.draw_line(x0, y0, x1, y0, red);
   				result.draw_line(x0, y1, x1, y1, red);
   				result.draw_line(x0, y0, x0, y1, red);
   				result.draw_line(x1, y0, x1, y1, red);
   			}
   			else if(count == 1) {
   				result.draw_line(x0, y0, x1, y0, blue);
   				result.draw_line(x0, y1, x1, y1, blue);
   				result.draw_line(x0, y0, x0, y1, blue);
   				result.draw_line(x1, y0, x1, y1, blue);
   			}
   			else if (count == 2) {
   				result.draw_line(x0, y0, x1, y0, yellow);
   				result.draw_line(x0, y1, x1, y1, yellow);
   				result.draw_line(x0, y0, x0, y1, yellow);
   				result.draw_line(x1, y0, x1, y1, yellow);
   			}
   			else if (count == 4) {
   				result.draw_line(x0, y0, x1, y0, green);
   				result.draw_line(x0, y1, x1, y1, green);
   				result.draw_line(x0, y0, x0, y1, green);
   				result.draw_line(x1, y0, x1, y1, green);
   			}
   			else if (count == 5) {
   				result.draw_line(x0, y0, x1, y0, r1);
   				result.draw_line(x0, y1, x1, y1, r1);
   				result.draw_line(x0, y0, x0, y1, r1);
   				result.draw_line(x1, y0, x1, y1, r1);
   			}
   			else if (count == 6) {
   				result.draw_line(x0, y0, x1, y0, r2);
   				result.draw_line(x0, y1, x1, y1, r2);
   				result.draw_line(x0, y0, x0, y1, r2);
   				result.draw_line(x1, y0, x1, y1, r2);
   			}
   			else {
   				result.draw_line(x0, y0, x1, y0, red);
   				result.draw_line(x0, y1, x1, y1, red);
   				result.draw_line(x0, y0, x0, y1, red);
   				result.draw_line(x1, y0, x1, y1, red);
   			}
   			x0 = origin_img._width;
   			x1 = 0;
   			y0 = origin_img._height;
   			y1 = 0;
   			count++;
   		}
   		x0 = xmin < x0 ? xmin : x0;
   		x1 = xmax > x1 ? xmax : x1;
   		y0 = ymin < y0 ? ymin : y0;
   		y1 = ymax > y1 ? ymax : y1;
   	}
   	return result;
   }
   ~~~



部分结果如下：

![b9c7db1ad671618d83a5b953107163b](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/b9c7db1ad671618d83a5b953107163b.bmp)

![IMG_20191204_013929](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/IMG_20191204_013929.bmp)

![3a989dab03baf453bcc666a5d36287e](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/3a989dab03baf453bcc666a5d36287e.bmp)

![0c07317f1990f9e3d8b68ce2e874cc7](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/0c07317f1990f9e3d8b68ce2e874cc7.bmp)

![06c249ec6a341610b364c43b8b45e54](https://github.com/Tifinity/MyImage/raw/master/ComputerVersion/FinalProject1/06c249ec6a341610b364c43b8b45e54.bmp)



### 收集名片

> 每位同学收集 30 张名片, 并拍照发给 TA(要求光照均匀且充足明亮, 拍照清晰)。

已发送助教邮箱。