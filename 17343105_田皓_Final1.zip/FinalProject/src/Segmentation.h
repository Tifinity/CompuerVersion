#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <opencv2/opencv.hpp>
#include <opencv2/ml/ml.hpp>
#include "CImg.h"

using namespace std;
using namespace cv;
using namespace ml;
using namespace cimg_library;

class Segmentation {
private:
	bool* visit;
	vector<vector<Point>> connect;
	vector<vector<int>> number;
	vector<vector<int>> red_number;
	vector<vector<int>> green_number;
	vector<vector<int>> blue_number;
	vector<vector<vector<int>>> red_number2;
	vector<vector<vector<int>>> green_number2;
	vector<vector<vector<int>>> blue_number2;
	vector<vector<int>> bracket;
	vector<string> knn_number;

	CImg<unsigned char> origin_img;					//
	CImg<unsigned char> gray_img;					//
	CImg<unsigned char> delate_img;					//
	CImg<unsigned char> result_img;					//
	CImg<unsigned char> result2_img;
	CImg<unsigned char> ruler_img;
	CImg<unsigned char> back_img;
	vector<int> ruler_pos;
	vector<int> red_pos;
	vector<int> blue_pos;
	vector<int> green_pos;

	Mat origin_img_cv;
	Mat res_cv;

	int getThreshold(CImg<unsigned char> src);
	CImg<unsigned char> background(CImg<unsigned char> input);
	CImg<unsigned char> toGrayScale(CImg<unsigned char> input);
	CImg<unsigned char> delate(CImg<unsigned char> input);					//
	void dfs(int x, int y, vector<Point>& tmp);
	void find_connection();
	void process_connection();
	CImg<unsigned char> draw_red(CImg<unsigned char> input);
	CImg<unsigned char> draw_blue(CImg<unsigned char> input);
	CImg<unsigned char> draw_green(CImg<unsigned char> input);
	CImg<unsigned char> find_ruler(CImg<unsigned char> input);
	CImg<unsigned char> find_brackets(CImg<unsigned char> input);
	CImg<unsigned char> draw_info(CImg<unsigned char> input);
	void knn_red();
	void knn_blue();
	void knn_green();

	Mat getdata(Mat img);
	void model();

	void svm_train();
	void svm_test();
	void knn_train();
	void knn_test();
	void adaboost_train();
	void adaboost_test();

public:
	Segmentation(string);
	~Segmentation();
};