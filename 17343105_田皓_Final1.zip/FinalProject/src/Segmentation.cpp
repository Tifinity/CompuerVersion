#include "Segmentation.h"
#include <sstream>

using namespace std;

Segmentation::Segmentation(string filename) {
	origin_img_cv = imread(filename);
	CImg<unsigned char> tmp(filename.c_str());
	origin_img = tmp;
	if (!origin_img.data()) {
		cout << "Could not open or find the image" << std::endl;
		exit(-1);
	}

	visit = new bool[origin_img._width * origin_img._height];
	for (int i = 0; i < origin_img._width * origin_img._height; i++)
		visit[i] = false;

	origin_img.display("origin image");
	delate_img = toGrayScale(origin_img);
	delate_img.display("gray_img image");
	find_connection();
	result_img = draw_info(origin_img);
	result_img.display("result image");
	string s = string("./result/");
	string filepath = s + filename;
	result_img.save(filepath.c_str());

	//process_connection();
	//getdata(origin_img_cv);

	//result_img = draw_red(origin_img);
	//result_img = draw_blue(result_img);
	//result_img = draw_green(result_img);
	//result_img.display("result image");

	//knn_red();
	//knn_blue();
	//knn_green();
	//result_img = find_brackets(result_img);
	//result_img.display("result image");
	//result_img.save("1.bmp");	
}

Segmentation::~Segmentation() {
	delete[]visit;
}

CImg<unsigned char> Segmentation::toGrayScale(CImg<unsigned char> input) {
	CImg<unsigned char> grayscaled = CImg<unsigned char>(input._width, input._height);
	cimg_forXY(input, x, y) {
		int b = input(x, y, 0);
		int g = input(x, y, 1);
		int r = input(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	cimg_forXY(grayscaled, x, y) {
		if (grayscaled(x, y) < 180) {
			grayscaled(x, y) = 0;
		}
		else {
			grayscaled(x, y) = 255;
		}
	}
	return grayscaled;
}

void Segmentation::dfs(int x, int y, vector<Point>& tmp) {
	if (x < 0 || x >= delate_img._width ||
		y < 0 || y >= delate_img._height ||
		visit[y * delate_img._width + x] ||
		delate_img(x, y) != 0)
		return;

	Point tmpp = Point(x, y);
	tmp.push_back(tmpp);
	visit[y * delate_img._width + x] = true;

	for (int i = -1; i < 2; i++) {
		for (int j = -1; j < 2; j++) {
			if (i != 0 || j != 0) {
				dfs(x + i, y + j, tmp);
			}
		}
	}
}

void Segmentation::find_connection() {
	cimg_forXY(delate_img, x, y) {
		if (delate_img(x, y) == 0 && visit[y * delate_img._width + x] == false) {
			vector<Point> tmp;
			dfs(x, y, tmp);
			connect.push_back(tmp);
		}
	}
}

bool mycmpx(vector<int> a, vector<int> b) {
	return a[0] < b[0];
}
bool mycmpy(vector<Point> a, vector<Point> b) {
	return a[0].y < b[0].y;
}

CImg<unsigned char> Segmentation::draw_info(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char red[] = { 255,0,0 };
	const unsigned char green[] = { 0,255,0 };
	const unsigned char blue[] = { 0,0,255 };
	const unsigned char yellow[] = { 255,255,0 };
	const unsigned char r1[] = { 255,0,255 };
	const unsigned char r2[] = { 0,255,255 };

	sort(connect.begin(), connect.end(), mycmpy);
	int x0 = origin_img._width, x1 = 0;
	int y0 = origin_img._height, y1 = 0;
	int tmpy = 136;
	int count = 0;
	for (int i = 0; i < connect.size(); i++) {
		int xmin = origin_img._width, xmax = 0;
		int ymin = origin_img._height, ymax = 0;
		if (connect[i].size() < 50 || connect[i].size() > 15000) continue;
		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}	
		if (abs(ymin - tmpy) > 65) {
			tmpy = ymin;
			if (count == 0) {
				result.draw_line(x0, y0, x1, y0, red);
				result.draw_line(x0, y1, x1, y1, red);
				result.draw_line(x0, y0, x0, y1, red);
				result.draw_line(x1, y0, x1, y1, red);
			}
			else if(count == 1) {
				result.draw_line(x0, y0, x1, y0, blue);
				result.draw_line(x0, y1, x1, y1, blue);
				result.draw_line(x0, y0, x0, y1, blue);
				result.draw_line(x1, y0, x1, y1, blue);
			}
			else if (count == 2) {
				result.draw_line(x0, y0, x1, y0, yellow);
				result.draw_line(x0, y1, x1, y1, yellow);
				result.draw_line(x0, y0, x0, y1, yellow);
				result.draw_line(x1, y0, x1, y1, yellow);
			}
			else if (count == 4) {
				result.draw_line(x0, y0, x1, y0, green);
				result.draw_line(x0, y1, x1, y1, green);
				result.draw_line(x0, y0, x0, y1, green);
				result.draw_line(x1, y0, x1, y1, green);
			}
			else if (count == 5) {
				result.draw_line(x0, y0, x1, y0, r1);
				result.draw_line(x0, y1, x1, y1, r1);
				result.draw_line(x0, y0, x0, y1, r1);
				result.draw_line(x1, y0, x1, y1, r1);
			}
			else if (count == 6) {
				result.draw_line(x0, y0, x1, y0, r2);
				result.draw_line(x0, y1, x1, y1, r2);
				result.draw_line(x0, y0, x0, y1, r2);
				result.draw_line(x1, y0, x1, y1, r2);
			}
			else {
				result.draw_line(x0, y0, x1, y0, red);
				result.draw_line(x0, y1, x1, y1, red);
				result.draw_line(x0, y0, x0, y1, red);
				result.draw_line(x1, y0, x1, y1, red);
			}
			x0 = origin_img._width;
			x1 = 0;
			y0 = origin_img._height;
			y1 = 0;
			count++;
		}
		x0 = xmin < x0 ? xmin : x0;
		x1 = xmax > x1 ? xmax : x1;
		y0 = ymin < y0 ? ymin : y0;
		y1 = ymax > y1 ? ymax : y1;
	}
		
	return result;
}