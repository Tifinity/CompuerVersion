#include <iostream>
#include <cmath>
#include "canny.h"

#define BLUR 2
#define GRAY_THRESSHOLD 170
#define VOTE_THRESSHOLD 300
#define PEAK_DIS 60

#define MINR 15
#define MAXR 20
#define R_THRESSHOLD 140
#define O_THRESSHOLD 140
#define DIS_THRESSHOLD 50

using namespace std;
using namespace cimg_library;

canny::canny(string filename) {
	CImg<unsigned char> temp(filename.c_str());
	img = temp;
	if (!img._data) cout << "Could not open or find the image" << std::endl;
	else {
		peaks.clear();
		max_vote.clear();
		lines.clear();

		img.display("Image");
		grayscaled = toGrayScale(); 
		gFiltered = grayscaled.blur(BLUR);
		sFiltered = sobel(); 
		sFiltered.display("sFiltered");
		
		/*draw circle*/
		//houghCirclesTransform(sFiltered, MINR, MAXR);

		/*draw line*/
		houghImg = init_houghspace(sFiltered);
		find_peaks(houghImg);
		houghImg.display("hough space");
		result = draw_lines();
		result.display("lines");
		result = draw_points();
		result.display("points");
		result = draw_edges();
		result.display("edges");
		//result.save("coin-timg (3).bmp");
	}
}

CImg<unsigned char> canny::toGrayScale() {
	grayscaled = CImg<unsigned char>(img._width, img._height);
	cimg_forXY(img, x, y) {
		int b = img(x, y, 0);
		int g = img(x, y, 1);
		int r = img(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	return grayscaled;
}

CImg<unsigned char> canny::sobel() {
    //Sobel X Filter
    double x1[] = {-1.0, 0, 1.0};
    double x2[] = {-2.0, 0, 2.0};
    double x3[] = {-1.0, 0, 1.0};
    vector<vector<double>> xFilter(3);
    xFilter[0].assign(x1, x1+3);
    xFilter[1].assign(x2, x2+3);
    xFilter[2].assign(x3, x3+3);
    //Sobel Y Filter
    double y1[] = {1.0, 2.0, 1.0};
    double y2[] = {0, 0, 0};
    double y3[] = {-1.0, -2.0, -1.0};
    vector<vector<double>> yFilter(3);
    yFilter[0].assign(y1, y1+3);
    yFilter[1].assign(y2, y2+3);
    yFilter[2].assign(y3, y3+3);
    //Limit Size
    int size = (int)xFilter.size()/2;
	CImg<unsigned char> filteredImg = CImg<unsigned char>(gFiltered._width - 2 * size, gFiltered._height - 2 * size);
    angles = CImg<unsigned char>(gFiltered._width - 2 * size, gFiltered._height - 2 * size, 1); //AngleMap
	for (int i = size; i < gFiltered._width - size; i++) {
		for (int j = size; j < gFiltered._height - size; j++) {
			double sumx = 0;
            double sumy = 0;        
			for (int x = 0; x < xFilter.size(); x++) {
				for (int y = 0; y < xFilter.size(); y++) {
					sumx += xFilter[x][y] * (double)(gFiltered(i + x - size, j + y - size)); //Sobel_X Filter Value
					sumy += yFilter[x][y] * (double)(gFiltered(i + x - size, j + y - size)); //Sobel_Y Filter Value
				}
			}
            double sumxsq = sumx * sumx;
            double sumysq = sumy * sumy;
            double sq2 = sqrt(sumxsq + sumysq);
            if(sq2 > 255) sq2 =255;
            filteredImg(i-size, j-size) = sq2;
            if(sumx==0) angles(i-size, j-size) = 90;
            else angles(i-size, j-size) = atan(sumy/sumx);
		}
	}
    return filteredImg;
}

CImg<unsigned char> canny::nonMaxSupp() {
	CImg<unsigned char> nonMaxSupped = CImg<unsigned char>(sFiltered._width - 2, sFiltered._height - 2);
	for (int i = 1; i < sFiltered._width - 1; i++) {
		for (int j = 1; j < sFiltered._height - 1; j++) {
			float Tangent = angles(i, j);
			nonMaxSupped(i - 1, j - 1) = sFiltered(i, j);
			//Horizontal Edge
			if (((-22.5 < Tangent) && (Tangent <= 22.5)) || ((157.5 < Tangent) && (Tangent <= -157.5))) {
				if ((sFiltered(i, j) < sFiltered(i, j + 1)) || (sFiltered(i, j) < sFiltered(i, j - 1)))
					nonMaxSupped(i - 1, j - 1) = 0;
			}
			//Vertical Edge
			if (((-112.5 < Tangent) && (Tangent <= -67.5)) || ((67.5 < Tangent) && (Tangent <= 112.5))) {
				if ((sFiltered(i, j) < sFiltered(i + 1, j)) || (sFiltered(i, j) < sFiltered(i - 1, j)))
					nonMaxSupped(i - 1, j - 1) = 0;
			}

			//-45 Degree Edge
			if (((-67.5 < Tangent) && (Tangent <= -22.5)) || ((112.5 < Tangent) && (Tangent <= 157.5))) {
				if ((sFiltered(i, j) < sFiltered(i - 1, j + 1)) || (sFiltered(i, j) < sFiltered(i + 1, j - 1)))
					nonMaxSupped(i - 1, j - 1) = 0;
			}

			//45 Degree Edge
			if (((-157.5 < Tangent) && (Tangent <= -112.5)) || ((22.5 < Tangent) && (Tangent <= 67.5))) {
				if ((sFiltered(i, j) < sFiltered(i + 1, j + 1)) || (sFiltered(i, j) < sFiltered(i - 1, j - 1)))
					nonMaxSupped(i - 1, j - 1) = 0;
			}
		}
	}
	return nonMaxSupped;
}

CImg<unsigned char> canny::threshold(CImg<unsigned char> imgin, int low, int high) {
	if (low > 255) low = 255;
	if (high > 255) high = 255;
	CImg<unsigned char> EdgeMat = CImg<unsigned char>(imgin._width, imgin._height);
	for (int i = 0; i < imgin._width; i++) {
		for (int j = 0; j < imgin._height; j++) {
			EdgeMat(i, j) = imgin(i, j);
			if (EdgeMat(i, j) > high) EdgeMat(i, j) = 255;
			else if (EdgeMat(i, j) < low) EdgeMat(i, j) = 0;
			else {
				bool anyHigh = false;
				bool anyBetween = false;
				for (int x = i - 1; x < i + 2; x++) {
					for (int y = j - 1; y < j + 2; y++) {
						if (x <= 0 || y <= 0 || EdgeMat._width || y > EdgeMat._height) //Out of bounds
							continue;
						else {
							if (EdgeMat(x, y) > high) {
								EdgeMat(i, j) = 255;
								anyHigh = true;
								break;
							}
							else if (EdgeMat(x, y) <= high && EdgeMat(x, y) >= low)
								anyBetween = true;
						}
					}
					if (anyHigh) break;
				}
				if (!anyHigh && anyBetween)
					for (int x = i - 2; x < i + 3; x++) {
						for (int y = j - 1; y < j + 3; y++) {
							if (x < 0 || y < 0 || x > EdgeMat._width || y > EdgeMat._height) //Out of bounds
								continue;
							else {
								if (EdgeMat(x, y) > high) {
									EdgeMat(i, j) = 255;
									anyHigh = true;
									break;
								}
							}
						}
						if (anyHigh) break;
					}
				if (!anyHigh) EdgeMat(i, j) = 0;
			}
		}
	}
	return EdgeMat;
}

CImg<float> canny::init_houghspace(CImg<unsigned char> img) {
	int max_r = (int)sqrt(img.width() * img.width() + img.height() * img.height());
	CImg<float> hough(360, max_r, 1, 1, 0);
	cimg_forXY(img, x, y) {
		double grad = img(x, y);
		if (grad > GRAY_THRESSHOLD) {	
			cimg_forX(hough, theta) {
				int r = (int)(x * cos(theta * cimg::PI / 180) + y * sin(theta * cimg::PI / 180));
				if (r >= 0 && r < max_r) hough(theta, r)++;
			}
		}
	}
	return hough;
}

void canny::find_peaks(CImg<float> houghspace) {
	cimg_forXY(houghspace, theta, p) {
		if (houghspace(theta, p) > VOTE_THRESSHOLD) {
			bool flag = true;
			for (int i = 0; i < peaks.size(); i++) {
				if (sqrt((peaks[i].first - theta) * (peaks[i].first - theta)
					+ (peaks[i].second - p) * (peaks[i].second - p)) < PEAK_DIS) {
					flag = false;
					if (max_vote[i] < houghspace(theta, p)) {
						peaks[i] = make_pair(theta, p);
						max_vote[i] = houghspace(theta, p);
					}
				}
			}
			if (flag) {
				peaks.push_back(make_pair(theta, p));
				max_vote.push_back(houghspace(theta, p));
			}
		}
	}
}

CImg<unsigned char> canny::draw_lines() {
	CImg<unsigned char> result = img;
	for (int i = 0; i < peaks.size(); i++) {
		double theta = double(peaks[i].first) * cimg::PI / 180;
		double k = -cos(theta) / sin(theta);
		double b = double(peaks[i].second) / sin(theta);
		lines.push_back(make_pair(k,b));
		cout << "Line " << i << ": y = " << "-x/" << tan(theta) << " + " << peaks[i].second/sin(theta)<< endl;
	}

	double lines_color[] = { 0, 0, 255 };
	for (int i = 0; i < lines.size(); i++) {
		const int x0 = (double)(0 - lines[i].second) / lines[i].first;
		const int x1 = (double)(result._height - lines[i].second) / lines[i].first;
		const int y0 = 0 * lines[i].first + lines[i].second;
		const int y1 = result._width * lines[i].first + lines[i].second;
		if (abs(lines[i].first) > 1) {
			result.draw_line(x0, 0, x1, result._height, lines_color);
		}
		else {
			result.draw_line(0, y0, result._width, y1, lines_color);
		}
	}
	return result;
}

CImg<unsigned char> canny::draw_points() {
	CImg<unsigned char> result2 = result;
	int k = 0;
	for (int i = 0; i < lines.size(); i++) {
		for (int j = i + 1; j < lines.size(); j++) {
			double k0 = lines[i].first;
			double k1 = lines[j].first;
			double b0 = lines[i].second;
			double b1 = lines[j].second;
			double x = (b1 - b0) / (k0 - k1);
			double y = (k0 * b1 - k1 * b0) / (k0 - k1);
			if (x >= 0 && x < result2._width && y >= 0 && y < result2._height) {
				intersections.push_back(make_pair(x,y));
				cout << "Intersection " << k++ << ": x = " << x << ", y = " << y << endl;
			}
		}
	}

	const double intersections_color[] = { 255, 0, 0 };
	for (int i = 0; i < intersections.size(); i++) {
		result2.draw_circle(intersections[i].first, intersections[i].second, 50, intersections_color);
	}
	return result2;
}

CImg<unsigned char> canny::draw_edges() {
	const double yellow[] = { 255, 0, 0 };
	int crossPoint = 0;
	for (int i = 1; i < 4; i++) {
		double temp_k = (double)(intersections[i].second - intersections[0].second) / (double)(intersections[i].first - intersections[0].first);
		double temp_b = (double)intersections[0].second - temp_k * (double)intersections[0].first;
		int flag = 0;
		for (int j = 1; j < 4; j++) {
			if (j != i) {
				double diff = (double)intersections[j].second - (temp_k * (double)intersections[j].first + temp_b);
				if (flag == 0) {
					flag = diff > 0 ? 1 : -1;
				}
				else {
					if (flag == 1 && diff <= 0 || flag == -1 && diff > 0) {
						crossPoint = i;
						break;
					}
				}
			}
		}
		if (crossPoint != 0) break;
	}
	for (int i = 1; i < 4; i++) {
		if (i != crossPoint) {
			result.draw_line(
				intersections[i].first, intersections[i].second,
				intersections[0].first, intersections[0].second, yellow);
			result.draw_line(
				intersections[i].first, intersections[i].second,
				intersections[crossPoint].first, intersections[crossPoint].second, yellow);
		}
	}
	return result;
}


void canny::houghCirclesTransform(CImg<unsigned char> sobel, int minR, int maxR) {
	result = img;
	int width = sobel._width;
	int height = sobel._height;
	int max = 0;
	unsigned char blue[3] = { 0, 0, 255 };
	unsigned char red[3] = { 255, 0, 0 };
	circles.clear();
	circleWeight.clear();
	already_circles.clear();

	for (int r = minR; r < maxR; r += 1) {
		max = 0;
		houghImg = CImg<float>(width, height, 1, 1, 0);
		cimg_forXY(sobel, x, y) {
			int value = sobel(x, y);
			if (value > GRAY_THRESSHOLD) {
				for (int i = 0; i < 360; i++) {
					int x0 = x - r * cos(i * (maxR - minR));
					int y0 = y - r * sin(i * (maxR - minR));
					if (x0 > 0 && x0 < width && y0 > 0 && y0 < height) {
						houghImg(x0, y0)++;
					}
				}
			}
		}
		cimg_forXY(houghImg, x, y) {
			if (houghImg(x, y) > max) {
				max = houghImg(x, y);
			}
		}
		if (max > R_THRESSHOLD) {
			voteSet.push_back(make_pair(max, r));
		}
		//houghImg.display("hough");
	}

	sort(voteSet.begin(), voteSet.end(), [](const pair<int, int>& x, const pair<int, int>& y) -> int {
		return x.first > y.first;
		});

	for (int i = 0; i < voteSet.size(); i++) {
		houghImg = CImg<float>(width, height, 1, 1, 0);
		cimg_forXY(sobel, x, y) {
			int value = sobel(x, y);
			if (value > GRAY_THRESSHOLD) {
				for (int j = 0; j < 360; j++) {
					int x0 = x - voteSet[i].second * cos(j * (maxR - minR));
					int y0 = y - voteSet[i].second * sin(j * (maxR - minR));
					if (x0 > 0 && x0 < width && y0 > 0 && y0 < height) {
						houghImg(x0, y0)++;
					}
				}
			}
		}
		//houghImg.display("hough");

		cimg_forXY(houghImg, x, y) {
			if (houghImg(x, y) > O_THRESSHOLD) {
				bool flag = true;
				for (int i = 0; i < circles.size(); i++) {
					if (sqrt((circles[i].first - x) * (circles[i].first - x)
						+ (circles[i].second - y) * (circles[i].second - y)) < DIS_THRESSHOLD) {
						flag = false;
						if (circleWeight[i] < houghImg(x, y)) {
							circles[i] = make_pair(x, y);
							circleWeight[i] = houghImg(x, y);
						}
					}
				}
				if (flag) {
					circles.push_back(make_pair(x, y));
					circleWeight.push_back(houghImg(x, y));
				}
			}
		}
		int r = voteSet[i].second;

		for (int i = 0; i < circles.size(); i++) {
			int x = circles[i].first;
			int y = circles[i].second;
			int flag = 1;
			cout << "Բ�İ뾶Ϊ��" << r << endl;
			cout << "Բ������Ϊ��" << x << " " << y << endl;
			
			for (int j = 0; j < already_circles.size(); j++) {
				if (sqrt((already_circles[j].first - x) * (already_circles[j].first - x) + (already_circles[j].second - y) * (already_circles[j].second - y)) < 30) {
					flag = 0;
					break;
				}
			}
			if (flag) {
				already_circles.push_back(make_pair(x, y));
				result.draw_circle(x, y, r, blue, 5.0f, 1);
				result.draw_circle(x, y, 5, red);
			}	
		}
		//result.display("result");
	}
	result.display("result");
	cout << "Բ�ĸ���Ϊ��" << already_circles.size() << endl;
}