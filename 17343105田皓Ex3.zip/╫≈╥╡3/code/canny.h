#ifndef _CANNY_
#define _CANNY_
#include <string>
#include <vector>
#include "CImg.h"

using namespace std;
using namespace cimg_library;

class canny {
private:
	CImg<unsigned char> img;
	CImg<unsigned char> grayscaled;
	CImg<unsigned char> gFiltered;
	CImg<unsigned char> sFiltered;
	CImg<unsigned char> angles;
	CImg<unsigned char> non;
	CImg<unsigned char> th;
	CImg<float> houghImg;
	CImg<unsigned char> result; 
	CImg<unsigned char> result2;
	vector<pair<int, int>> peaks;
	vector<int> max_vote;
	vector<pair<double, double>> lines; 
	vector<pair<double, double>> intersections;

	vector<pair<int, int>> circles;
	vector<pair<int, int>> already_circles;
	vector<pair<int, int>> voteSet;
	vector<pair<int, int>> center;
	vector<int> circleWeight;


public:
	canny(string); //Constructor
	CImg<unsigned char> toGrayScale();

	CImg<unsigned char> sobel(); //Sobel filtering
	CImg<unsigned char> nonMaxSupp();
	CImg<unsigned char> threshold(CImg<unsigned char> imgin, int low, int high);

	CImg<float> init_houghspace(CImg<unsigned char> img);
	void find_peaks(CImg<float> hough);
	CImg<unsigned char> draw_lines();
	CImg<unsigned char> draw_points();
	CImg<unsigned char> draw_edges();

	void houghCirclesTransform(CImg<unsigned char> img, int, int); // ����Բ�任
	void drawCircle(int); // ��������Բ��
};

#endif
