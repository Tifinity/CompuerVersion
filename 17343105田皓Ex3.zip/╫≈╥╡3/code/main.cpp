#include <iostream>
#include <cmath>
#include "canny.h"

using namespace std;

int main() {
	char path[5][99] = {"Dataset-EX3/Dataset1/Dataset/IMG_20150320_143133.bmp"};
	for (int i = 0; i < 1; i++) {
		canny res(path[i]);
	}
	return 0;
}