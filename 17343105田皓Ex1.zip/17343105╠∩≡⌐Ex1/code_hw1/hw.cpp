#include "hw.h"

bool cmp(double x, double y) {
	if (abs(x - y) <= 0.5) return 1;
	return 0;
}

MyTest::MyTest(CImg<unsigned char> _img):img(_img) {};

MyTest::~MyTest() {};

void MyTest::my_display() {
	img.display();
}

void MyTest::my_color_change() {
	cimg_forXY(img, x, y) {
		if (img(x, y, 0) == 255 && img(x, y, 1) == 255 && img(x, y, 2) == 255) {
			img(x, y, 0) = 255;
			img(x, y, 1) = 0;
			img(x, y, 2) = 0;
		}
	}
	cimg_forXY(img, x, y) {
		if (img(x, y, 0) == 0 && img(x, y, 1) == 0 && img(x, y, 2) == 0) {
			img(x, y, 0) = 0;
			img(x, y, 1) = 255;
			img(x, y, 2) = 0;
		}
	}
}

void MyTest::draw_triangle_1() {
	double x0 = 50, y0 = 50 - 40 / 3 * pow(3, 0.5);
	double x1 = 30, y1 = 50 + 20 / 3 * pow(3, 0.5);
	double x2 = 70, y2 = y1;
	img(x1, y1, 0) = 0;
	img(x1, y1, 1) = 0;
	img(x1, y1, 2) = 255;
	img(x2, y2, 0) = 0;
	img(x2, y2, 1) = 0;
	img(x2, y2, 2) = 255;
	cimg_forXY(img, x, y) {
		double k1 = (y - y1) / (x - x1);
		double k2 = (y - y2) / (x - x2);
		if (y <= y2 && k1 >= -sqrt(3) && k1 <= 0 && k2 <= sqrt(3) && k2 >= 0 && x >= x1 && x <= x2) {
			img(x, y, 0) = 0;
			img(x, y, 1) = 0;
			img(x, y, 2) = 255;
		}
	}
}

void MyTest::draw_triangle_2() {
	unsigned char blue[] = { 0,0,255 };
	int x0 = 50, y0 = 50 - 40 / 3 * pow(3, 0.5);
	int x1 = 30, y1 = 50 + 20 / 3 * pow(3, 0.5);
	int x2 = 70, y2 = y1;
	img.draw_triangle(x0, y0, x1, y1, x2, y2, blue);
}

void MyTest::draw_circle_1() {
	cimg_forXY(img, x, y) {
		if (pow(pow(x - 50, 2) + pow(y - 50, 2), 0.5) < 15) {
			img(x, y, 0) = 255;
			img(x, y, 1) = 255;
			img(x, y, 2) = 0;
		}
	}
}

void MyTest::draw_circle_2() {
	unsigned char yellow[] = { 255, 255, 0 };
	img.draw_circle(50, 50, 15, yellow);
}

void MyTest::draw_line_1() {
	double x0 = 100 * cos(45 * pi / 180);
	double y0 = 100 * sin(45 * pi / 180);
	cimg_forXY(img, x, y) {
		if (x == 0) {
			if (y == 0) {
				img(x, y, 0) = 0;
				img(x, y, 1) = 255;
				img(x, y, 2) = 0;
			}
		}
		else {
			if (cmp((double)y, (double)x * tan(45 * pi / 180)) && (double)x <= x0 && (double)y <= y0) {
				img(x, y, 0) = 0;
				img(x, y, 1) = 255;
				img(x, y, 2) = 0;
			}
		}
	}
}

void MyTest::draw_line_2() {
	unsigned char blue[] = { 0,255,0 };
	img.draw_line(0, 0, 100 * cos(45 * pi / 180), 100 * sin(45 * pi / 180), blue);
}

/*ex1Ϊ��ʹ�ýӿ�*/
void MyTest::ex_1() {
	my_display();
	my_color_change();
	my_display();
	draw_triangle_1();
	my_display();
	draw_circle_1();
	my_display();
	draw_line_1();
	my_display();
	img.save("2.bmp");
}

/*ex2Ϊʹ�ýӿ�*/
void MyTest::ex_2() {
	my_display();
	my_color_change();
	my_display();
	draw_triangle_2();
	my_display();
	draw_circle_2();
	my_display();
	draw_line_2();
	my_display();
	img.save("2.bmp");
}