#pragma once
#include "CImg.h"
using namespace cimg_library;

const double pi = 3.14159265;

class MyTest {
private:
	CImg<unsigned char> img;
public:
	MyTest(CImg<unsigned char> img);
	~MyTest();
	void my_display();
	void my_color_change();
	void draw_triangle_1();
	void draw_triangle_2();
	void draw_circle_1();
	void draw_circle_2();
	void draw_line_1();
	void draw_line_2();
	void ex_1();
	void ex_2();
};