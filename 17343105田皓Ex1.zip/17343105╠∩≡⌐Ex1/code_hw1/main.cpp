#include <iostream>
#include "hw.h"

using namespace std;
int main() {
	CImg<unsigned char> src;
	src.load_bmp("1.bmp");
	MyTest m(src);
	int c = 0;
	cout << "��1��ʹ�ýӿڣ���2ʹ�ýӿ�" << endl;
	cin >> c;
	if(c==1) m.ex_1();
	else m.ex_2();
	return 0;
}