# 文件目录

- code 代码

- image
  - ex5result 作业5结果
  - test_data 测试集
  - test_raw_data 原始图片
  - train_data 训练集
  - train_raw_data 原始图片
- model 训练模型
- report 实验报告

​	