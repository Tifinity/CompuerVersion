#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
#include <opencv2/ml/ml.hpp> 

#include "Cut.h"
#include "CImg.h"

using namespace std;
using namespace cv;
using namespace ml;

int main() {
	string input_path = "train_raw_data/CC -  (1).bmp";
	Cut c(input_path);
}