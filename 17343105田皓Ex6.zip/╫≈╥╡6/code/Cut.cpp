#include "Cut.h"
#include <sstream>

using namespace std;

Cut::Cut(string filename) {
	origin_img_cv = imread(filename);
	CImg<unsigned char> tmp(filename.c_str());
	origin_img = tmp;
	if (!origin_img.data()) {
		cout << "Could not open or find the image" << std::endl;
		exit(-1);
	}

	visit = new bool[origin_img._width * origin_img._height];
	for (int i = 0; i < origin_img._width * origin_img._height; i++)
		visit[i] = false;

	//origin_img.display("origin image");
	//delate_img = toGrayScale(origin_img);
	//delate_img.display("gray_img image");
	//delate_img = delate(gray_img);
	//delate_img.display("delate image");
	//find_connection();
	//process_connection();
	//getdata(origin_img_cv);

	//result_img = draw_red(origin_img);
	//result_img = draw_blue(result_img);
	//result_img = draw_green(result_img);
	//result_img.display("result image");
	
	//knn_red();
	//knn_blue();
	//knn_green();
	//result_img = find_brackets(result_img);
	//result_img.display("result image");
	//result_img.save("1.bmp");
	knn_train();
	svm_train();
	//adaboost_train();
	knn_test();
	svm_test();
	//adaboost_test();
}

Cut::~Cut() {
	delete[]visit;
}

int Cut::getThreshold(CImg<unsigned char> src) {
	int th;
	const int GrayScale = 256;	//��ͨ��ͼ���ܻҶ�256��
	int pixCount[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ���ظ���
	int pixSum = src._width * src._height;//ͼ�������ص�
	float pixPro[GrayScale] = { 0 };//ÿ���Ҷ�ֵ��ռ�����ر���
	float w0, w1, u0tmp, u1tmp, u0, u1, deltaTmp, deltaMax = 0;

	cimg_forXY(src, x, y) {
		pixCount[src(x, y)]++;//ͳ��ÿ���Ҷȼ������صĸ���
	}

	for (int i = 0; i < GrayScale; i++) {
		pixPro[i] = pixCount[i] * 1.0 / pixSum;//����ÿ���Ҷȼ���������Ŀռ����ͼ��ı���  
	}
	//�������д�0��255�Ҷȼ�����ֵ�ָ�������������һ������䷽�����
	for (int i = 0; i < GrayScale; i++) {
		w0 = w1 = u0tmp = u1tmp = u0 = u1 = deltaTmp = 0;
		for (int j = 0; j < GrayScale; j++) {
			if (j <= i) {
				w0 += pixPro[j];
				u0tmp += j * pixPro[j];
			} else {
				w1 += pixPro[j];
				u1tmp += j * pixPro[j];
			}
		}
		u0 = u0tmp / w0;
		u1 = u1tmp / w1;
		deltaTmp = (float)(w0 * w1 * pow((u0 - u1), 2)); //��䷽�ʽ g = w1 * w2 * (u1 - u2) ^ 2
		if (deltaTmp > deltaMax) {
			deltaMax = deltaTmp;
			th = i;
		}
	}
	return th;
}

CImg<unsigned char> Cut::background(CImg<unsigned char> input) {
	CImg<unsigned char> result = toGrayScale(input);
	int th = getThreshold(input);
	cout << th << endl;
	cimg_forXY(result, x, y) {
		if (result(x, y) > th) {
			result(x, y) = 255;
		} 
		else {
			result(x, y) = 0;
		}
	}
	return result;
}

CImg<unsigned char> Cut::toGrayScale(CImg<unsigned char> input) {
	CImg<unsigned char> grayscaled = CImg<unsigned char>(input._width, input._height);
	cimg_forXY(input, x, y) {
		int b = input(x, y, 0);
		int g = input(x, y, 1);
		int r = input(x, y, 2);
		double newValue = (r * 0.2126 + g * 0.7152 + b * 0.0722);
		grayscaled(x, y) = newValue;
	}
	//grayscaled.display("gray_img image");
	cimg_forXY(grayscaled, x, y) {
		if (grayscaled(x, y) < 160) {
			grayscaled(x, y) = 0;
		}
		else {
			grayscaled(x, y) = 255;
		}
	}
	return grayscaled;
}

CImg<unsigned char> Cut::delate(CImg<unsigned char> input) {
	int size = 3;
	CImg<unsigned char> output = CImg<unsigned char>(input._width, input._height);
	for (int i = size / 2; i < output._width - size / 2; i++) {
		for (int j = size / 2; j < output._height - size / 2; j++) {
			int m = 255;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					if (input(i + x - size / 2, j + y - size / 2) < m) {
						m = input(i + x - size / 2, j + y - size / 2);
					}
				}
			}
			output(i, j) = m;
		}
	}
	return output;
}

void Cut::dfs(int x, int y, vector<Point> &tmp) {
	if (x < 0 || x >= delate_img._width || 
		y < 0 || y >= delate_img._height || 
		visit[y * delate_img._width + x] ||
		delate_img(x, y) != 0)
		return;

	Point tmpp = Point(x, y);
	tmp.push_back(tmpp);
	visit[y * delate_img._width + x] = true;

	for (int i = -1; i < 2; i++) {
		for (int j = -1; j < 2; j++) {
			if (i != 0 || j != 0) {
				dfs(x + i, y + j, tmp);
			}
		}
	}
}

void Cut::find_connection() {
	cimg_forXY(delate_img, x, y) {
		if (delate_img(x, y) == 0 && visit[y * delate_img._width + x] == false) {
			vector<Point> tmp;
			dfs(x, y, tmp);
			connect.push_back(tmp);
		}
	}
}

bool mycmpx(vector<int> a, vector<int> b) {
	return a[0] < b[0];
}
bool mycmpy(vector<int> a, vector<int> b) {
	return a[2] < b[2];
}

Mat Cut::getdata(Mat origin_img_cv) {
	Mat res = origin_img_cv;
	string dir = "train_data/zhuan/";
	int xmin = delate_img._width, xmax = 0;
	int ymin = delate_img._height, ymax = 0;
	for (int i = 0; i < number.size(); i++) {
		string path = dir + to_string(i+0) + ".png";
		cout << path << endl;
		Rect rect(number[i][0] - 2, number[i][2] - 2, number[i][1] - number[i][0] + 4, number[i][3] - number[i][2] + 4);
		Mat tmp = res(rect);
		imwrite(path, tmp);
	}
	return res;
}

void Cut::process_connection() {
	for (int i = 0; i < connect.size(); i++) {
		vector<int> tmp;
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		if (connect[i].size() >= 40 && connect[i].size() <= 370) {
			for (int j = 0; j < connect[i].size(); j++) {
				xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
				xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
				ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
				ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
			}
			tmp.push_back(xmin);
			tmp.push_back(xmax);
			tmp.push_back(ymin);
			tmp.push_back(ymax);
			number.push_back(tmp);
		}
	}
}

CImg<unsigned char>  Cut::draw_red(CImg<unsigned char> input){
	CImg<unsigned char> result = input;
	const unsigned char red[] = { 255,0,0 };
	int xmin = delate_img._width, xmax = 0;
	int ymin = delate_img._height, ymax = 0;
	ymin = 30;
	ymax = 105;
	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			red_number.push_back(number[i]);
		}
	}
	red_pos.push_back(xmin - 1);
	red_pos.push_back(xmax + 1);
	red_pos.push_back(ymin - 1);
	red_pos.push_back(ymax + 1);
	result.draw_line(red_pos[0], red_pos[2], red_pos[1], red_pos[2], red);
	result.draw_line(red_pos[0], red_pos[3], red_pos[1], red_pos[3], red);
	result.draw_line(red_pos[0], red_pos[2], red_pos[0], red_pos[3], red);
	result.draw_line(red_pos[1], red_pos[2], red_pos[1], red_pos[3], red);
	sort(red_number.begin(), red_number.end(), mycmpx);
	int tmpy = red_number[0][0];
	int i = 0;
	vector<vector<int>> tmp;
	while (i < red_number.size()) {
		if (abs(red_number[i][0] - tmpy) > 2) {
			red_number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(red_number[i]);
		tmpy = red_number[i][0];
		i++;
	}
	red_number2.push_back(tmp);
	for (int i = 0; i < red_number2.size(); i++) {
		sort(red_number2[i].begin(), red_number2[i].end(), mycmpy);
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		for (int j = 0; j < red_number2[i].size(); j++) {
			xmin = red_number2[i][j][0] < xmin ? red_number2[i][j][0] : xmin;
			xmax = red_number2[i][j][1] > xmax ? red_number2[i][j][1] : xmax;
			ymin = red_number2[i][j][2] < ymin ? red_number2[i][j][2] : ymin;
			ymax = red_number2[i][j][3] > ymax ? red_number2[i][j][3] : ymax;
		}
		result.draw_line(xmin, ymin, xmax, ymin, red);
		result.draw_line(xmin, ymax, xmax, ymax, red);
		result.draw_line(xmin, ymin, xmin, ymax, red);
		result.draw_line(xmax, ymin, xmax, ymax, red);
	}
	return result;
}

CImg<unsigned char>  Cut::draw_blue(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char blue[] = { 0,0,255 };
	int xmin = delate_img._width, xmax = 0;
	int ymin = 1390;
	int ymax = 1470;
	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			blue_number.push_back(number[i]);
		}
	}
	blue_pos.push_back(xmin - 1);
	blue_pos.push_back(xmax + 1);
	blue_pos.push_back(ymin - 1);
	blue_pos.push_back(ymax + 1);
	result.draw_line(blue_pos[0], blue_pos[2], blue_pos[1], blue_pos[2], blue);
	result.draw_line(blue_pos[0], blue_pos[3], blue_pos[1], blue_pos[3], blue);
	result.draw_line(blue_pos[0], blue_pos[2], blue_pos[0], blue_pos[3], blue);
	result.draw_line(blue_pos[1], blue_pos[2], blue_pos[1], blue_pos[3], blue);
	sort(blue_number.begin(), blue_number.end(), mycmpx);
	int tmpy = blue_number[0][0];
	int i = 0;
	vector<vector<int>> tmp;
	while (i < blue_number.size()) {
		if (abs(blue_number[i][0] - tmpy) > 2) {
			blue_number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(blue_number[i]);
		tmpy = blue_number[i][0];
		i++;
	}
	blue_number2.push_back(tmp);
	for (int i = 0; i < blue_number2.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		for (int j = 0; j < blue_number2[i].size(); j++) {
			xmin = blue_number2[i][j][0] < xmin ? blue_number2[i][j][0] : xmin;
			xmax = blue_number2[i][j][1] > xmax ? blue_number2[i][j][1] : xmax;
			ymin = blue_number2[i][j][2] < ymin ? blue_number2[i][j][2] : ymin;
			ymax = blue_number2[i][j][3] > ymax ? blue_number2[i][j][3] : ymax;
		}
		result.draw_line(xmin, ymin, xmax, ymin, blue);
		result.draw_line(xmin, ymax, xmax, ymax, blue);
		result.draw_line(xmin, ymin, xmin, ymax, blue);
		result.draw_line(xmax, ymin, xmax, ymax, blue);
	}
	return result;
}

CImg<unsigned char>  Cut::draw_green(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char green[] = { 0,255,0 };
	int xmin = delate_img._width, xmax = 0;
	int ymin = 1490;
	int ymax = 1515;
	for (int i = 0; i < number.size(); i++) {
		if (number[i][3] <= ymax && number[i][2] >= ymin) {
			xmin = number[i][0] < xmin ? number[i][0] : xmin;
			xmax = number[i][1] > xmax ? number[i][1] : xmax;
			green_number.push_back(number[i]);
		}
	}
	green_pos.push_back(xmin - 2);
	green_pos.push_back(xmax + 2);
	green_pos.push_back(ymin - 2);
	green_pos.push_back(ymax + 2);
	result.draw_line(green_pos[0], green_pos[2], green_pos[1], green_pos[2], green);
	result.draw_line(green_pos[0], green_pos[3], green_pos[1], green_pos[3], green);
	result.draw_line(green_pos[0], green_pos[2], green_pos[0], green_pos[3], green);
	result.draw_line(green_pos[1], green_pos[2], green_pos[1], green_pos[3], green);
	sort(green_number.begin(), green_number.end(), mycmpx);
	int tmpx = green_number[0][0];
	int tmpy = green_number[0][2];
	int i = 0;
	vector<vector<int>> tmp;
	while (i < green_number.size()) {
		if (abs(green_number[i][2] - tmpy) > 2 || abs(green_number[i][0] - tmpx) > 30) {
			green_number2.push_back(tmp);
			tmp.clear();
		}
		tmp.push_back(green_number[i]);
		tmpx = green_number[i][0];
		tmpy = green_number[i][2];
		i++;
	}
	green_number2.push_back(tmp);
	for (int i = 0; i < green_number2.size(); i++) {
		sort(green_number2[i].begin(), green_number2[i].end(), mycmpy);
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		for (int j = 0; j < green_number2[i].size(); j++) {
			xmin = green_number2[i][j][0] < xmin ? green_number2[i][j][0] : xmin;
			xmax = green_number2[i][j][1] > xmax ? green_number2[i][j][1] : xmax;
			ymin = green_number2[i][j][2] < ymin ? green_number2[i][j][2] : ymin;
			ymax = green_number2[i][j][3] > ymax ? green_number2[i][j][3] : ymax;
		}
		result.draw_line(xmin, ymin, xmax, ymin, green);
		result.draw_line(xmin, ymax, xmax, ymax, green);
		result.draw_line(xmin, ymin, xmin, ymax, green);
		result.draw_line(xmax, ymin, xmax, ymax, green);
	}
	return result;
}

CImg<unsigned char> Cut::find_ruler(CImg<unsigned char> input) {
	CImg<unsigned char> result = origin_img;
	const unsigned char blue[] = { 0,0,255 };
	float max_scale = 0;
	int rx0=0, ry0=0, rx1=0, ry1=0;

	for (int i = 0; i < connect.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;

		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}

		float tmp_scale = (xmax - xmin)/ (ymax - ymin);
		if (tmp_scale > max_scale) {
			max_scale = tmp_scale;
			rx0 = xmin;
			rx1 = xmax;
			ry0 = ymin;
			ry1 = ymax;
		}		
	}
	ry0 -= 10;
	ry1 += 30;

	ruler_pos.push_back(rx0);
	ruler_pos.push_back(rx1);
	ruler_pos.push_back(ry0);
	ruler_pos.push_back(ry1);

	result.draw_line(rx0, ry0, rx1, ry0, blue);
	result.draw_line(rx0, ry1, rx1, ry1, blue);
	result.draw_line(rx0, ry0, rx0, ry1, blue);
	result.draw_line(rx1, ry0, rx1, ry1, blue);
	return result;
}

CImg<unsigned char> Cut::find_brackets(CImg<unsigned char> input) {
	CImg<unsigned char> result = input;
	const unsigned char red[] = { 255,0,0 };

	for (int i = 0; i < connect.size(); i++) {
		int xmin = delate_img._width, xmax = 0;
		int ymin = delate_img._height, ymax = 0;
		vector<int> tmp;
		
		for (int j = 0; j < connect[i].size(); j++) {
			xmin = connect[i][j].x < xmin ? connect[i][j].x : xmin;
			xmax = connect[i][j].x > xmax ? connect[i][j].x : xmax;
			ymin = connect[i][j].y < ymin ? connect[i][j].y : ymin;
			ymax = connect[i][j].y > ymax ? connect[i][j].y : ymax;
		}
		//float tmp_scale = (xmax - xmin) / (ymax - ymin);

		if (ymin >= 1369 && ymax <= 1400) {
			tmp.push_back(xmin);
			tmp.push_back(xmax);
			tmp.push_back(ymin);
			tmp.push_back(ymax);
			bracket.push_back(tmp);
		}
	}
	
	sort(bracket.begin(), bracket.end(), mycmpx);
	for (int i = 0; i < bracket.size(); i++) {
		result.draw_line(bracket[i][0], bracket[i][2], bracket[i][1], bracket[i][2], red);
		result.draw_line(bracket[i][0], bracket[i][3], bracket[i][1], bracket[i][3], red);
		result.draw_line(bracket[i][0], bracket[i][2], bracket[i][0], bracket[i][3], red);
		result.draw_line(bracket[i][1], bracket[i][2], bracket[i][1], bracket[i][3], red);
	}
	cout << "����" << endl;
	for (int i = 0; i < bracket.size(); i++) {
		float tmpleft = (2031 - bracket[i][0]) * 0.0046;
		float tmpright = tmpleft - (bracket[i][1] - bracket[i][0]) * 0.0046;
		cout << tmpleft << " " << tmpright << endl;	
		int tmpx = bracket[i][0];
		for (int i = 0; i < blue_number2.size(); i++) {
			if (abs(blue_number2[i][0][0] - tmpx) < 40) {
				cout << knn_number[i] << endl;
			}
		}
	}
	return result;
}

void Cut::knn_red() {
	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		char adr[128] = { 0 };
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			Mat srcimage = imread(filename[j]);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);
	cout << "red" << endl;
	for (int i = 0; i < red_number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < red_number2[i].size(); j++) {
			string tmp = "";
			//cout << number2[i][0] << " " << number2[i][1] << " " << number2[i][2] << number2[i][3] << endl;
			Rect rect(red_number2[i][j][0] - 1, red_number2[i][j][2] - 1, red_number2[i][j][1] - red_number2[i][j][0] + 2, red_number2[i][j][3] - red_number2[i][j][2] + 2);
			Mat testdata = origin_img_cv(rect);
			transpose(testdata, testdata);
			flip(testdata, testdata, 1);
			resize(testdata, testdata, Size(12, 16));
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 1) numstr += '.';
		}
		reverse(numstr.begin(), numstr.end());
		cout << numstr << endl;
	}
}

void Cut::knn_blue() {
	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		char adr[128] = { 0 };
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			Mat srcimage = imread(filename[j]);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);
	cout << "blue" << endl;
	for (int i = 0; i < blue_number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < blue_number2[i].size(); j++) {
			string tmp = "";
			Rect rect(blue_number2[i][j][0] - 1, blue_number2[i][j][2] - 1, blue_number2[i][j][1] - blue_number2[i][j][0] + 2, blue_number2[i][j][3] - blue_number2[i][j][2] + 2);
			Mat testdata = origin_img_cv(rect);

			transpose(testdata, testdata);
			flip(testdata, testdata, 1);

			resize(testdata, testdata, Size(12, 16));
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 1) numstr += '.';
		}
		reverse(numstr.begin(), numstr.end());
		cout << numstr << endl;
		knn_number.push_back(numstr);
	}
}

void Cut::knn_green() {
	Mat traindata, trainlabel;
	int k = 5, testnum = 0, truenum = 0;
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		char adr[128] = { 0 };
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			Mat srcimage = imread(filename[j]);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(cv::ml::KNearest::BRUTE_FORCE);
	knn->train(traindata, cv::ml::ROW_SAMPLE, trainlabel);
	cv::Mat nearests(1, k, CV_32F);
	cout << "green" << endl;
	for (int i = 0; i < green_number2.size(); i++) {
		string numstr = "";
		for (int j = 0; j < green_number2[i].size(); j++) {
			string tmp = "";
			Rect rect(green_number2[i][j][0] - 1, green_number2[i][j][2] - 1, green_number2[i][j][1] - green_number2[i][j][0] + 2, green_number2[i][j][3] - green_number2[i][j][2] + 2);
			Mat tmpdata = origin_img_cv(rect);
			resize(tmpdata, tmpdata, Size(12, 16));
			Mat testdata = tmpdata.clone();
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			stringstream ss;
			ss << response;
			ss >> tmp;
			numstr += tmp;
			if (j == 0) numstr += '.';
		}
		cout << numstr << endl;

	}
}

void Cut::knn_train() {
	// train
	Mat traindata, trainlabel;
	int k = 5;
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		char adr[128] = { 0 };
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			Mat srcimage = imread(filename[j]);
			srcimage = srcimage.reshape(1, 1);
			traindata.push_back(srcimage);
			trainlabel.push_back(i);
		}
	}
	traindata.convertTo(traindata, CV_32F);
	cv::Ptr<KNearest> knn = KNearest::create();
	knn->setDefaultK(k);
	knn->setIsClassifier(true);
	knn->setAlgorithmType(KNearest::BRUTE_FORCE);
	cout << "train..." << endl;
	knn->train(traindata, ROW_SAMPLE, trainlabel);
	knn->KNearest::save("model/model_knn.xml");
	cout << "save model in \"model / model_knn.xml\"" << endl;
}

void Cut::knn_test(){
	// test
	Ptr<KNearest> knn = KNearest::create();
	knn = KNearest::load("model/model_knn.xml");
	int cnt = 0;
	int sum = 0;
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		char adr[128] = { 0 };
		sprintf_s(adr, "test_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			Mat testdata = imread(filename[j]);
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = knn->predict(testdata);
			if (response == i) cnt++;
			sum++;
		}
	}
	cout << "knn: " << 1.0 * cnt / sum  << endl;
}

void Cut::svm_train() {
	// train
	Mat trainData, trainLabel;
	char adr[128] = { 0 };
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename, false);
		for (int j = 0; j < filename.size(); j++) {
			Mat srcimage = imread(filename[j], 0);
			Mat t;
			resize(srcimage, srcimage, Size(12, 16));
			srcimage.copyTo(t);
			trainData.push_back(t.reshape(0, 1));
			trainLabel.push_back(Mat(1, 1, CV_32S, &i));
		}
	}
	trainData.convertTo(trainData, CV_32F);
	Ptr<SVM> svm = SVM::create();
	svm->setType(SVM::C_SVC);
	svm->setKernel(SVM::LINEAR);
	Ptr<TrainData> tData = TrainData::create(trainData, ROW_SAMPLE, trainLabel);
	cout << "train..." << endl;
	svm->trainAuto(tData);
	svm->SVM::save("model/model_svm.xml");
	cout << "save model in \"model / model_svm.xml\"" << endl;
}

void Cut::svm_test() {
	//test
	Ptr<SVM> svm = SVM::create();
	svm = SVM::load("model/model_svm.xml");
	int cnt = 0;
	int sum = 0;
	char adr_test[128] = { 0 };
	for (int i = 0; i < 10; i++) {
		Mat testData;
		vector<String> filename;
		sprintf_s(adr_test, "test_data\\%d\\*.png", i);
		glob(adr_test, filename, false);
		for (int j = 0; j < filename.size(); j++) {
			Mat testimage = imread(filename[j], 0);
			Mat t;
			resize(testimage, testimage, Size(12, 16));
			testimage.copyTo(t);
			testData.push_back(t.reshape(0, 1));
		}
		testData.convertTo(testData, CV_32F);
		Mat result;
		int rst = svm->predict(testData, result);
		for (auto j = 0; j < result.rows; j++) {
			if (result.at<float>(j, 0) == i) cnt++;
			sum++;
		}	
	}
	cout << "svm: "<< 1.0 * cnt / sum << endl;
}

void Cut::adaboost_train() {
	// train
	Mat traindata, trainlabel;
	int var_count = 12 * 16 * 3;
	int class_count = 10;
	char adr[128] = { 0 };
	for (int i = 0; i < 10; i++) {
		vector<String> filename;
		sprintf_s(adr, "train_data\\%d\\*.png", i);
		glob(adr, filename);
		for (int j = 0; j < filename.size(); j++) {
			for (int k = 0; k < class_count; k++) {
				Mat img = imread(filename[j]);
				img = img.reshape(1, img.rows * img.cols * 3);
				img.convertTo(img, CV_32FC1);
				Mat temp(1, 1, CV_32FC1);
				temp.at<float>(0, 0) = k;
				img.push_back(temp);
				img = img.reshape(1, 1);
				traindata.push_back(img);
				trainlabel.push_back(k);
			}
		}
	}
	traindata.convertTo(traindata, CV_32F);
	
	Mat var_type(1, var_count + 1, CV_8U);
	var_type.setTo(Scalar::all(VAR_ORDERED));
	var_type.at<uchar>(var_count) = VAR_CATEGORICAL;
	
	Ptr<Boost> ada = Boost::create();
	//�㷨����
	ada->setBoostType(Boost::GENTLE);
	//��������������
	ada->setWeakCount(100);
	//0��1֮�����ֵ
	ada->setWeightTrimRate(0.95);
	//�������������
	ada->setMaxDepth(5);
	//�Ƿ���������ѵ�
	ada->setUseSurrogates(false);
	//�������������
	//ada->setPriors(Mat(priors));
	//ѵ��ģ��
	cout << "train..." << endl;
	Ptr<TrainData> tdata = TrainData::create(
		traindata, ROW_SAMPLE, trainlabel, 
		noArray(), noArray(), noArray(), 
		var_type
	);
	ada->train(tdata);
	//�����������浽�ļ���
	ada->save("model/model_adaboost.xml");
	cout << "save model in \"model / model_knn.xml\"" << endl;
}

void Cut::adaboost_test() {
	Ptr<Boost> ada = Boost::create();
	ada = Boost::load("model/model_adaboost.xml");
	int cnt = 0;
	int sum = 0;
	char adr_test[128] = { 0 };
	for (int i = 0; i < 10; i++) {
		Mat testData;
		vector<String> filename;
		sprintf_s(adr_test, "test_data\\%d\\*.png", i);
		glob(adr_test, filename, false);
		for (int j = 0; j < filename.size(); j++) {
			Mat testdata = imread(filename[j]);
			testdata = testdata.reshape(1, 1);
			testdata.convertTo(testdata, CV_32F);
			int response = ada->predict(testdata);
			if (response == i) cnt++;
			sum++;
		}
	}
	cout << "adaboost: " << 1.0* cnt/ sum << endl;
}