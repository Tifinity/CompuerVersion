import opencv

def myflip():  
	for file in glob2.glob(dirr + '/*'):  
		print(file)  
		pat = ".+\.(png)"  
		pattern = re.findall(pat, file)  
		splitName = file.split(".")  
		newName = splitName[0] + "_flip" + '.' + pattern[0]  
		img = cv2.imread(file)  
		(heigh, wide, deep)=img.shape  
		if wide > heigh:  
		    img = cv2.transpose(img)  
		    img = cv2.flip(img, 1)   
		res_img = cv2.resize(img, (12, 16), interpolation = cv2.INTER_AREA)  
		cv2.imwrite(newName, res_img)  
		os.remove(file)  

def myrename():  
	num = 1  
	for file in glob2.glob(dirr + '/*'):  
		print(file)  
		pat = ".+\.(png)"  
		pattern = re.findall(pat, file)  
		newname = dirr+ '/'+dirr + '_' + str(num) + '.' + pattern[0]  
		print(newname)  
		os.rename(file, newname)  
		num+=1 

#myflip()
#myrename()